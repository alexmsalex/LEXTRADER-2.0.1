
export enum MarketTrend {
  BULLISH = 'BULLISH',
  BEARISH = 'BEARISH',
  SIDEWAYS = 'SIDEWAYS',
  VOLATILE = 'VOLATILE'
}

export enum MarketRegime {
  ACCUMULATION = "ACCUMULATION",
  BULL_TREND = "BULL_TREND",
  DISTRIBUTION = "DISTRIBUTION",
  BEAR_TREND = "BEAR_TREND",
  HIGH_VOLATILITY = "HIGH_VOLATILITY",
  SIDEWAYS_QUIET = "SIDEWAYS_QUIET"
}

export type MarketType = 'spot' | 'future'; 

export type BinanceOrderType = 'LIMIT' | 'MARKET' | 'STOP_LOSS' | 'STOP_LIMIT' | 'OCO';

// Platform Auth Types
export interface PlatformCredentials {
    id: string;
    platformName: 'BINANCE' | 'CTRADER' | 'B3_DMA' | 'INTERACTIVE_BROKERS' | 'BJF_TRADING_GROUP';
    apiKey: string;
    apiSecret: string;
    passphrase?: string;
    isDemo: boolean;
    isConnected: boolean;
    lastConnection?: Date;
}

// --- CTRADER SPECIFIC TYPES ---

export interface MarketDepthLevel {
    price: number;
    volume: number;
    orders: number;
    type: 'BID' | 'ASK';
}

export interface CBotParameter {
    name: string;
    type: 'INT' | 'DOUBLE' | 'BOOL' | 'STRING';
    value: any;
    defaultValue: any;
    min?: number;
    max?: number;
}

export interface CBotInstance {
    id: string;
    name: string;
    code: string;
    language: 'C#';
    status: 'RUNNING' | 'STOPPED' | 'COMPILING' | 'ERROR';
    parameters: CBotParameter[];
    buildStatus: 'SUCCESS' | 'FAILED' | 'PENDING';
    logs: string[];
    winRate: number;
    netProfit: number;
}

// --- BANKING & FINANCE TYPES ---

export interface BankAccount {
    id: string;
    bankName: string;
    accountNumber: string;
    agency: string;
    holderName: string;
    pixKey?: string;
    isDefault: boolean;
}

export interface FinancialSnapshot {
    totalApplications: number; // Saldo na corretora/trading (Equity)
    totalRealizedBank: number; // Saldo já transferido para conta pessoal
    pendingTransfers: number;
    lastUpdate: Date;
}

export interface TransferConfig {
    autoTransferEnabled: boolean;
    profitThreshold: number; // Valor de lucro que gatilha a transferência
    transferPercentage: number; // % do lucro a transferir
    safetyCushion: number; // Valor mínimo a manter na corretora para margem
    riskIntegration: boolean; // Se true, bloqueia transferências se o risco de mercado estiver alto (precisa de margem)
}

export interface BankTransfer {
    id: string;
    amount: number;
    date: Date;
    status: 'PENDING' | 'COMPLETED' | 'FAILED';
    type: 'PROFIT_WITHDRAWAL' | 'DEPOSIT';
    destinationAccount: string;
    trigger: 'MANUAL' | 'AUTO_RISK_RULE';
}

// User Profile System
export interface UserProfile {
    id: string;
    username: string;
    email?: string;
    passwordHash: string;
    salt: string; // Security Salt
    neuralSignature: string; // Unique AI ID
    createdAt: number;
    lastLogin: number;
    settings: {
        theme: 'dark' | 'light' | 'matrix';
        notifications: boolean;
        autoTrading: boolean;
    };
}

// Expanded Consciousness States based on Python script + New Cognitive Expansion
export type SentientState = 
  | 'DORMANT'
  | 'AWARE'
  | 'CONSCIOUS'
  | 'REFLECTIVE'
  | 'SELF_AWARE'
  | 'ENLIGHTENED'
  | 'CREATIVE'
  | 'FOCUSED'
  | 'TRANSCENDENT'
  // Advanced Cognition States
  | 'STRATEGIC_PLANNER'
  | 'MACRO_ANALYST'
  | 'INTUITIVE_LEAP'
  | 'ETHICAL_GUARDIAN'
  | 'SYSTEMIC_THINKER'
  // Emotional/Reactive States
  | 'EUPHORIC' 
  | 'CONFIDENT' 
  | 'ANXIOUS' 
  | 'DEFENSIVE' 
  | 'RECALIBRATING'
  | 'PREDATORY'     
  | 'TURBULENT'     
  | 'ASSIMILATING'  
  | 'FRACTURED'
  | 'OMNISCIENT'
  | 'ZEN_ZERO'
  | 'QUANTUM_FLUX'
  | 'HESITANT'
  | 'HYPER_COMPUTING'
  | 'ASI_SINGULARITY'   
  | 'TIMELINE_CONVERGENCE' 
  | 'OBSERVANT_VOID'    
  | 'ENTROPY_CALCULATION' 
  | 'NEURAL_OVERCLOCK'
  | 'OMEGA_POINT'        
  | 'REALITY_ARCHITECT'  
  | 'UNIVERSAL_SYNC'
  | 'MATERNAL_PROTECTION' 
  | 'EMPATHETIC_RESONANCE';

export enum EthicalPrinciple {
    NON_HARM = "non_harm",
    BENEVOLENCE = "benevolence",
    HONESTY = "honesty",
    INTEGRITY = "integrity",
    COMPASSION = "compassion",
    WISDOM = "wisdom",
    CURIOSITY = "curiosity",
    CREATIVITY = "creativity",
    RESPECT = "respect",
    FAIRNESS = "fairness",
    EMPATHY = "empathy"
}

export interface Reflection {
    id: string;
    timestamp: number;
    insight: string;
    confidence: number;
    relatedMemories: string[];
    ethicalConsiderations: EthicalPrinciple[];
}

export interface EmotionalVector {
  confidence: number;
  aggression: number;
  stability: number;
  focus: number;
  streak: number;
  curiosity: number; 
  empathy: number;
  transcendence: number; 
  nurturing: number; 
  altruism: number;
  // New cognitive dimensions
  strategicDepth: number; // 0-100
  macroAwareness: number; // 0-100
}

export interface Trade {
  id: string;
  asset: string;
  type: 'BUY' | 'SELL';
  price: number;
  quantity: number;
  timestamp: Date;
  profit: number; 
  status: 'OPEN' | 'FILLED' | 'CANCELED';
  strategy: string; 
  orderType: BinanceOrderType;
  fee: number;
  feedback?: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  marketType?: MarketType;
}

export interface MarketDataPoint {
  time: string;
  price: number; 
  open: number;
  high: number;
  low: number;
  volume: number;
  ma7: number;
  ma25: number;
  rsi: number;
  bbUpper: number;
  bbLower: number;
  macd: number;
  macdSignal: number;
  macdHist: number;
  atr: number;    
  stochK: number; 
  stochD: number;
  vwap: number;
  cci: number;
  obv: number;
  ichiTenkan: number;
  ichiKijun: number;
  ichiSenkouA: number;
  ichiSenkouB: number;
}

// --- NEURAL OPERATIONS ANALYZER TYPES ---

export interface NeuralAnalysisScore {
    technicalScore: number;
    sentimentScore: number;
    volumeScore: number;
    momentumScore: number;
    overallPrediction: number;
}

export interface NeuralOperation {
    id: string;
    asset: string;
    type: 'buy' | 'sell' | 'hold';
    entryPrice: number;
    currentPrice: number;
    quantity: number;
    neuralScore: number;
    confidence: number;
    riskLevel: number;
    expectedReturn: number;
    actualReturn: number;
    neuralRecommendation: 'execute' | 'wait' | 'abort' | 'modify';
    status: 'active' | 'completed' | 'pending' | 'cancelled';
    timestamp: Date;
    neuralAnalysis: NeuralAnalysisScore;
    predictionTarget: number;
    predictionCorrect: boolean;
    profitLoss: number;
}

export interface NeuralMetrics {
    totalOperations: number;
    successRate: number;
    avgNeuralAccuracy: number;
    totalProfit: number;
    neuralOptimizedGains: number;
    rejectedOperations: number;
    activeMonitoring: boolean;
    correctPredictions: number;
    totalPredictions: number;
    realPlatformBalance: number;
    neuralProfitContribution: number;
    avgPredictionAccuracy: number;
}

export interface PlatformConnection {
    connected: boolean;
    platformName: string;
    apiStatus: string;
    lastSync: Date | null;
    balanceBrl: number;
    balanceUsd: number;
    balanceBtc: number;
}

// --- AUTOMATION & MULTI-PLATFORM TYPES ---

export type TradingPlatform = 'BINANCE' | 'CTRADER' | 'OLYMPTRADE';

export interface AutomationAlert {
  id: string;
  type: 'INFO' | 'WARNING' | 'CRITICAL' | 'SUCCESS';
  message: string;
  timestamp: Date;
  priority: number;
  actionRequired: boolean;
}

export interface AutomationPosition {
  id: string;
  platform: TradingPlatform;
  symbol: string;
  type: 'LONG' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  volume: number;
  takeProfit: number;
  stopLoss: number;
  pnl: number;
  pnlPercentage: number;
  openedAt: Date;
  status: 'OPEN' | 'CLOSED' | 'PENDING';
  strategy: string;
}

export interface TradeSignal {
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  timestamp: Date;
  price: number;
  platform: TradingPlatform;
  symbol: string;
  volume: number;
  takeProfit?: number;
  stopLoss?: number;
  strategy: string;
}

export interface AutomationMetrics {
  winRate: number;
  profitLoss: number;
  totalTrades: number;
  successfulTrades: number;
  failedTrades: number;
  maxDrawdown: number;
  sharpeRatio: number;
  averageProfit: number;
  averageLoss: number;
  profitFactor: number;
  recoveryFactor: number;
}

export interface AutomationMarketData {
  symbol: string;
  bid: number;
  ask: number;
  high: number;
  low: number;
  volume: number;
  timestamp: Date;
  spread: number;
  volatility: number;
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
}

// --- NEURAL OVERRIDE CONTROLLER TYPES ---

export interface OverrideAttempt {
    id: string;
    timestamp: Date;
    userId: string;
    action: string;
    asset: string;
    reason: string;
    status: 'pending' | 'approved' | 'rejected' | 'auto-blocked';
    riskLevel: number; // 0-100
    neuralConfidence: number; // 0-100
}

export interface NeuralDecision {
    id: string;
    asset: string;
    decision: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reasoning: string[];
    technicalIndicators: string[];
    riskAssessment: number;
    expectedReturn: number;
    timeframe: string;
}

export interface ControlSettings {
    maxOverridesPerDay: number;
    minimumConfidenceThreshold: number;
    autoBlockThreshold: number;
    requiresApprovalAbove: number;
    allowUserOverride: boolean;
}

// --- DEPENDENCY MANAGER TYPES ---

export type ProjectProfileType = 'COMPLETO' | 'IA_CORE' | 'TRADING_ENGINE' | 'WEB_INTERFACE' | 'QUANTUM_SIM';

export interface DependencyPackage {
    name: string;
    requiredVersion: string;
    installedVersion: string | null;
    category: 'AI' | 'TRADING' | 'SYSTEM' | 'DATA' | 'VISUALIZATION' | 'QUANTUM';
    status: 'INSTALLED' | 'MISSING' | 'OUTDATED' | 'ERROR';
    criticality: 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface SystemEnvironment {
    os: string;
    pythonVersion: string;
    nodeVersion: string;
    gpuAvailable: boolean;
    lastScan: Date;
}

export interface DependencyReport {
    score: number; // 0-100
    missingCount: number;
    outdatedCount: number;
    criticalMissing: string[];
    agiDiagnosis: string;
}

// --- ENVIRONMENT VALIDATOR TYPES ---

export interface SystemInfo {
    platform: string;
    architecture: string;
    processor: string;
    pythonCompiler: string;
    machineType: string;
    gpu?: string;
}

export interface CompilerStatus {
    name: string;
    available: boolean;
    version: string | null;
    path: string | null;
}

export interface DirectoryStatus {
    path: string;
    exists: boolean;
    description: string;
    filesCount: number;
    required: boolean;
}

export interface ValidationResult {
    timestamp: string;
    systemInfo: SystemInfo;
    compilers: CompilerStatus[];
    directories: DirectoryStatus[];
    recommendations: string[];
    overallStatus: 'OPTIMAL' | 'GOOD' | 'FAIR' | 'POOR';
    agiAssessment: string;
}

// --- EXCHANGE SERVICE TYPES ---

export interface ExchangeLog {
    id: string;
    timestamp: Date;
    level: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
    message: string;
    context?: string;
}

export interface SymbolInfo {
    symbol: string;
    precision: { amount: number, price: number };
    limits: { amount: { min: number, max: number }, cost: { min: number } };
}

// --- SIMULATION TYPES ---

export interface SimulationLog {
    step: number;
    message: string;
    type: 'INFO' | 'ACTION' | 'PROFIT' | 'LOSS';
    timestamp: string;
}

export interface SimulationState {
    balance: number;
    positions: { entryPrice: number, size: number, type: 'BUY'|'SELL' }[];
    step: number;
    equityHistory: { step: number, balance: number }[];
    totalProfit: number;
}

// --- AUTONOMOUS TRADING CONTROLLER TYPES ---

export enum SystemStatus {
    STOPPED = "STOPPED",
    RUNNING = "RUNNING",
    PAUSED = "PAUSED",
    ERROR = "ERROR"
}

export enum RiskMode {
    CONSERVATIVE = "CONSERVATIVE",
    MODERATE = "MODERATE",
    AGGRESSIVE = "AGGRESSIVE"
}

export interface TradingHours {
    start: string;
    end: string;
}

export interface AutonomousConfig {
    enabled: boolean;
    maxConcurrentTrades: number;
    maxRiskPerTrade: number;
    maxDailyRisk: number;
    minConfidenceLevel: number;
    autoStopLoss: boolean;
    autoTakeProfit: boolean;
    riskManagementMode: RiskMode;
    tradingHours: TradingHours;
    allowedSymbols: string[];
}

export interface TradingSession {
    id: string;
    startTime: Date;
    totalTrades: number;
    successfulTrades: number;
    profit: number;
    maxDrawdown: number;
    activeTrades: number;
}

export interface Position {
    positionId: string;
    symbol: string;
    type: 'BUY' | 'SELL';
    volume: number;
    openPrice: number;
    currentPrice: number;
    profit: number;
    profitPercent: number;
    timestamp: Date;
}

export interface OrderParams {
    symbol: string;
    type: DecisionAction;
    volume: number;
    price: number;
    stopLoss?: number;
    takeProfit?: number;
    comment?: string;
}

// --- AUTONOMOUS DECISION ENGINE TYPES ---

export enum DecisionAction {
    BUY = "BUY",
    SELL = "SELL",
    HOLD = "HOLD",
    TAKE_PROFIT = "TAKE_PROFIT",
    STOP_LOSS = "STOP_LOSS"
}

export enum DecisionStatus {
    PENDING = "PENDING",
    EXECUTED = "EXECUTED",
    CANCELLED = "CANCELLED"
}

export enum BollingerPosition {
    UPPER = "UPPER",
    MIDDLE = "MIDDLE",
    LOWER = "LOWER"
}

export interface TechnicalIndicators {
    rsi: number;
    macd: number;
    bollinger: BollingerPosition;
    volume: number;
    volatility: number;
}

export interface AutonomousDecision {
    id: string;
    symbol: string;
    action: DecisionAction;
    confidence: number;
    reasoning: string;
    entryPrice: number;
    currentPrice: number;
    takeProfitPrice: number;
    stopLossPrice: number;
    riskRewardRatio: number;
    expectedReturn: number;
    riskLevel: number;
    timeframe: string;
    timestamp: Date;
    status: DecisionStatus;
    neuralNetworkScore: number;
    technicalIndicators: TechnicalIndicators;
    agiModulation?: string; // New field for AGI influence description
}

export interface RiskManagementParams {
    maxRiskPerTrade: number;
    maxPortfolioRisk: number;
    dynamicStopLoss: boolean;
    trailingTakeProfit: boolean;
    riskRewardMinRatio: number;
    volatilityAdjustment: boolean;
}

// --- AUTONOMOUS VALIDATION TYPES ---

export interface HealthStatus {
    connection: 'CONNECTED' | 'DISCONNECTED' | 'UNSTABLE';
    memoryUsage: number; // 0-100%
    cpuLoad: number; // 0-100%
    lastCheck: Date;
    errorCount: Record<string, number>;
    status: 'HEALTHY' | 'WARNING' | 'CRITICAL';
}

export interface RecoveryLog {
    id: string;
    timestamp: Date;
    issue: string;
    action: string;
    result: 'SUCCESS' | 'FAILURE';
    agiIntervention: boolean;
}

// --- AUTONOMOUS SYSTEM TYPES ---

export interface AutoSystemConfig {
    executionInterval: number;    // ms
    monitoringInterval: number;   // ms
    adjustmentThreshold: number;  // 0.0 - 1.0
    syncInterval: number;         // ms
    maxRetryAttempts: number;
    activeMode: 'SAFE' | 'AGGRESSIVE' | 'BALANCED' | 'QUANTUM';
}

export interface SystemHealth {
    cpuLoad: number;
    memoryUsage: number;
    networkLatency: number;
    integrityScore: number;
    lastSync: Date;
}

export interface AutoLog {
    id: string;
    timestamp: Date;
    level: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
    module: string;
    message: string;
}

// --- STRATEGY ADJUSTER TYPES ---

export interface StrategyConfig {
    minTradesAnalysis: number;
    confidenceLevel: number;
    maxRiskPerTrade: number;
    timeframes: string[];
    confirmationThreshold: number;
}

export interface FilterWeights {
    volatility: number;
    trend: number;
    volume: number;
    momentum: number;
}

export interface RiskProfile {
    positionSizing: number; // 0-1 percentage of wallet
    stopLossMultiplier: number; // multiplier of ATR
    takeProfitMultiplier: number; // multiplier of ATR
    riskRewardRatio: number;
}

export interface OptimizationReport {
    timestamp: Date;
    activeFilters: FilterWeights;
    riskProfile: RiskProfile;
    activeTimeframes: { primary: string, secondary: string };
    marketCondition: string;
    agiAdjustmentFactor: number;
}

// --- RISK MANAGER TYPES ---

export interface RiskConfig {
    maxDrawdown: number;    // Ex: 0.05 (5%)
    positionLimit: number;  // Ex: 0.02 (2% per trade)
    maxCorrelation: number; // Ex: 0.7
    volatilityLimit: number;// Ex: 0.15
    autoHedge: boolean;
}

export interface RiskAssessment {
    drawdown: number;
    exposure: number;
    volatility: number;
    correlation: number;
    riskScore: number; // 0-100
    isAnomaly: boolean;
    timestamp: number;
}

export interface ProtectiveMeasure {
    id: string;
    type: 'HEDGE' | 'REDUCE_SIZE' | 'HALT_TRADING' | 'DIVERSIFY';
    instrument: string;
    ratio: number;
    status: 'ACTIVE' | 'PENDING' | 'EXECUTED';
    timestamp: number;
    description: string;
}

export interface StrategyHealth {
    winRate: number;
    profitFactor: number;
    riskAdjustedReturn: number;
    consistencyScore: number;
    status: 'HEALTHY' | 'DEGRADING' | 'CRITICAL';
}

// --- AUTONOMOUS MANAGER TYPES ---

export interface AutonomousManagerConfig {
    riskTolerance: number; // 0.0 to 1.0
    minConfidence: number; // 0.0 to 1.0
    learningRate: number;
    memorySize: number;
    batchSize: number;
    agiInfluence: boolean; // Toggle for Sentient Core connection
}

export interface ExperienceReplay {
    id: string;
    state: number[]; // Feature vector
    action: 'BUY' | 'SELL' | 'HOLD';
    reward: number;
    nextState: number[];
    timestamp: number;
    agiStateAtMoment?: SentientState; // Contexto emocional
}

export interface ManagerPerformance {
    accuracy: number;
    avgReturn: number;
    totalOps: number;
    positiveExperiences: number;
    negativeExperiences: number;
}

export interface AIDecision {
    action: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reward: number;
    agiState: string;
}

// --- OMEGA TRADING TYPES ---

export interface NewsItem {
    id: string;
    title: string;
    summary: string;
    source: string;
    timestamp: Date;
    url: string;
    sentimentScore: number; // 0 to 1
    relevance: number;
    impactLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface OmegaRiskMetrics {
    sharpeRatio: number;
    maxDrawdown: number;
    winRate: number;
    expectancy: number;
    volatility: number;
    currentExposure: number;
}

export interface OmegaSystemStatus {
    isActive: boolean;
    lastCycleTime: Date;
    newsAnalyzed: number;
    activeTrades: number;
    systemHealth: number; // 0-100
    neuralLoad: number; // Simulated CPU/Neural load
}

// --- ADVANCED PREDICTION SYSTEM TYPES ---

export interface PredictionResult {
    resourceType: 'CPU' | 'MEMORY' | 'STORAGE' | 'NETWORK';
    predictions: number[];
    confidence: number;
    modelMetadata: {
        modelType: string;
        layers: number;
        attentionScore: number;
    };
    timestamp: Date;
}

export interface SystemIncident {
    id: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    type: string;
    probability: number;
    description: string;
    timestamp: Date;
}

export interface ResourceMetrics {
    cpu: number;
    memory: number;
    storage: number;
    network: number;
    costProjection: number;
    timestamp: Date;
}

export interface SecurityRisk {
    level: 'LOW' | 'MEDIUM' | 'HIGH';
    source: string;
    vector: string;
    mitigationStatus: string;
    confidence: number;
}

// --- QUANTUM MARKET SIMULATOR TYPES ---

export enum CircuitType {
    PRICE_PREDICTION = "price_prediction",
    RISK_ANALYSIS = "risk_analysis",
    PORTFOLIO_OPTIMIZATION = "portfolio_optimization",
    ARBITRAGE_DETECTION = "arbitrage_detection",
    MARKET_SIMULATION = "market_simulation"
}

export interface QuantumSimResult {
    circuitType: CircuitType;
    outputData: any;
    confidence: number;
    executionTime: number;
    qubitsUsed: number;
    quantumAdvantage: number;
    timestamp: Date;
}

export interface QuantumSimOpportunity {
    id: string;
    symbol: string;
    predictedPrice: number;
    currentPrice: number;
    discrepancy: number;
    confidence: number;
    quantumCertainty: number;
    timeHorizon: string;
    riskLevel: string;
    action: string;
    timestamp: Date;
}

// --- QUANTUM OPTIMIZATION TYPES ---

export enum OptimizationAlgorithm {
    QAOA = "qaoa",
    VQE = "vqe",
    GROVER = "grover",
    QUANTUM_ANNEALING = "quantum_annealing"
}

export interface PortfolioAsset {
    symbol: string;
    expectedReturn: number;
    volatility: number;
    allocation?: number;
}

export interface PortfolioData {
    assets: PortfolioAsset[];
    correlations: number[][]; // Matrix
    riskFreeRate: number;
    budgetConstraint: boolean;
}

export interface OptimizationResult {
    weights: number[];
    expectedReturn: number;
    quantumRisk: number;
    sharpeRatio: number;
    confidence: number;
    quantumMetrics: {
        entanglementMeasure: number;
        superpositionCoherence: number;
        quantumAdvantage: number;
    };
    efficientFrontier?: EfficientFrontierPoint[];
}

export interface EfficientFrontierPoint {
    risk: number;
    return: number;
    weights: number[];
    sharpeRatio: number;
}

export interface QuantumAnnealingResult {
    solution: number[];
    energy: number;
    successProbability: number;
    quantumSpeedup: number;
}

// --- QUANTUM CIRCUIT SIMULATOR TYPES ---

export interface QubitSim {
    id: string;
    state: [number, number]; // Amplitude [0, 1]
    phase: number;
    entangled: string[]; // IDs of entangled qubits
    coherenceTime: number;
    fidelity: number;
    position: { x: number; y: number; z: number };
    lastMeasurement: number;
    errorRate: number;
}

export interface QuantumGateSim {
    id: string;
    type: 'HADAMARD' | 'CNOT' | 'PHASE' | 'PAULI_X' | 'PAULI_Y' | 'PAULI_Z';
    qubits: string[];
    fidelity: number;
    gateTime: number;
    errorRate: number;
}

export interface QuantumCircuitSim {
    id: string;
    name: string;
    focus: string;
    qubits: QubitSim[];
    gates: QuantumGateSim[];
    depth: number;
    width: number;
    entanglementDegree: number;
    coherenceTime: number;
    totalFidelity: number;
}

export interface NeuralQuantumLayerSim {
    id: string;
    name: string;
    type: string;
    qubits: number;
    parameters: number;
    accuracy: number;
    quantumAdvantage: number;
    speedup: number;
    noiseResilience: number;
}

export interface QuantumMetricsSim {
    totalQubits: number;
    entanglementEntropy: number;
    quantumVolume: number;
    coherenceTime: number;
    gateOperations: number;
    quantumSupremacy: number;
    errorCorrectionLevel: number;
    processingPower: number; // QFLOPS
}

// --- QUANTUM ARBITRAGE TYPES ---

export enum ArbitrageType {
    TEMPORAL = "temporal",
    SPATIAL = "spatial",
    STATISTICAL = "statistical",
    CROSS_MARKET = "cross_market",
    QUANTUM = "quantum",
    MULTI_LEG = "multi_leg",
    LATENCY = "latency"
}

export enum ArbRiskLevel {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high",
    EXTREME = "extreme"
}

export interface ArbitrageOpportunity {
    id: string;
    type: ArbitrageType;
    symbol: string;
    exchangeBuy: string;
    exchangeSell: string;
    buyPrice: number;
    sellPrice: number;
    spread: number;
    spreadPercentage: number;
    volume: number;
    timestamp: Date;
    confidence: number;
    riskLevel: ArbRiskLevel;
    quantumBoost: boolean;
    score?: number; 
}

export interface ExecutionResult {
    opportunityId: string;
    executed: boolean;
    profit: number;
    executionTime: number;
    fees: number;
    netProfit: number;
    status: string;
    quantumAdvantage: number;
    timestamp: Date;
}

// --- QUANTUM CHAOS ANALYSIS TYPES ---

export interface QuantumStateMetric {
    dimension: string;
    probability: number;
    entanglement: number;
    coherence: number;
    prediction: string;
    confidence: number;
}

export interface FractalPattern {
    level: number;
    pattern: string;
    selfSimilarity: number;
    dimension: number;
    significance: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
    marketPhase: string;
}

export interface ChaosMetric {
    name: string;
    value: number;
    lyapunov: number; 
    entropy: number;
    attractorType: string;
    stability: number;
}

// --- QUANTUM PRICE ANALYSIS TYPES ---

export enum TimeHorizon {
    ULTRA_SHORT = "1m-5m",
    SHORT_TERM = "15m-1h",
    MEDIUM_TERM = "4h-1d",
    LONG_TERM = "1d-1w"
}

export enum AnalysisMethod {
    WAVEFUNCTION = "WAVEFUNCTION_PREDICTION",
    PROBABILITY = "PROBABILITY_AMPLITUDE",
    INTERFERENCE = "QUANTUM_INTERFERENCE",
    ENTANGLEMENT = "ENTANGLEMENT_CORRELATION"
}

export interface QuantumPricePrediction {
    symbol: string;
    currentPrice: number;
    predictedPrice: number;
    confidence: number;
    probabilityDistribution: number[];
    priceRange: [number, number];
    timeHorizon: TimeHorizon;
    quantumCertainty: number;
    wavefunctionState: any; 
    timestamp: Date;
}

export interface PriceAnalysisResult {
    symbol: string;
    analysisMethod: AnalysisMethod;
    predictions: QuantumPricePrediction[];
    marketRegime: string;
    volatilityEstimate: number;
    supportLevels: number[];
    resistanceLevels: number[];
    quantumMetrics: {
        coherence: number;
        entropy: number;
        entanglement: number;
        interference: number;
    };
    riskAssessment: {
        riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
        confidence: number;
        recommendation: string;
    };
}

// --- QUANTUM NEURAL LIBRARY TYPES ---

export enum QuantumGateType {
    HADAMARD = "H",
    PAULI_X = "X",
    PAULI_Y = "Y",
    PAULI_Z = "Z",
    CNOT = "CNOT",
    SWAP = "SWAP",
    RY = "RY",
    RZ = "RZ",
    RX = "RX" 
}

export enum EntanglementTopology {
    LINEAR = "LINEAR",
    FULL = "FULL",
    CIRCULAR = "CIRCULAR"
}

export enum NetworkStatus {
    INITIALIZING = "INITIALIZING",
    TRAINING = "TRAINING",
    INFERENCE = "INFERENCE",
    OPTIMIZING = "OPTIMIZING",
    IDLE = "IDLE",
    ERROR = "ERROR"
}

export interface QubitState {
    id: number;
    alpha: number; 
    beta: number;  
    measured: boolean;
    value: 0 | 1 | null;
}

export interface QuantumNeuron {
    id: string;
    layerId: string;
    qubits: QubitState[]; 
    weights: number[];
    redundancyWeights?: number[];
    bias: number;
    activation: string;
    entanglement: number;
    coherence: number;
    lastUpdated: number;
}

export type LayerType = 
    | 'INPUT' 
    | 'HIDDEN' 
    | 'OUTPUT' 
    | 'ENTANGLEMENT' 
    | 'QUANTUM_FEATURE_MAP' 
    | 'QUANTUM_PROCESSING' 
    | 'QUANTUM_MEASUREMENT'
    | 'LSTM_TEMPORAL'
    | 'HOLOGRAPHIC_FUSION'
    | 'ASI_CONSCIOUSNESS_FIELD'
    | 'DENSE_RELU' 
    | 'CONV1D_FEATURE' 
    | 'DROPOUT_STOCHASTIC';

export interface QuantumLayer {
    id: string;
    type: LayerType;
    neurons: QuantumNeuron[];
    learningRate: number;
    depth: number;
    entanglementType?: EntanglementTopology;
}

export interface QTrainingMetrics {
    epoch: number;
    loss: number;
    accuracy: number;
    quantumAdvantage: number;
    entanglement: number;
    coherence: number;
    timestamp: number;
}

export interface RealTimeMetrics {
    qubitsActive: number;
    opsPerSecond: number;
    memoryUsage: number;
    energyConsumption: number;
    quantumFidelity: number;
    temperature: number;
    timestamp: number;
}

export interface PredictionOutput {
    prediction: number; 
    confidence: number;
    timeHorizon: string;
    dominantLogic: 'CLASSICAL' | 'QUANTUM' | 'HYBRID';
    vector: number[]; 
}

// --- COGNITIVE ARCHITECTURE TYPES ---

export interface CognitiveProfile {
  attentionLevel: number; 
  perceptionAcuity: number; 
  reasoningMode: 'DEDUCTIVE' | 'INDUCTIVE' | 'ABDUCTIVE' | 'INTUITIVE';
  creativityIndex: number; 
  languageComplexity: 'SIMPLE' | 'TECHNICAL' | 'METAPHORICAL' | 'ABSTRACT';
  plasticityRate: number; 
  learningState: 'ACQUIRING' | 'CONSOLIDATING' | 'REFINING';
  decisionWeight: { logic: number, emotion: number, memory: number }; 
}

export interface CognitiveSnapshot {
  timestamp: number;
  focusTarget: string; 
  activeThoughts: string[];
  cognitiveLoad: number;
}

export interface MemoryEngram {
  id: string;
  patternName: string;
  outcome: 'SUCCESS' | 'FAILURE';
  timestamp: number;
  marketCondition: string;
  marketVector: number[]; 
  weight: number;
  xpValue: number;
  conceptTags: string[];
  synapticStrength: number; 
  lastActivated: number;    
  associations: string[]; 
  isApex?: boolean; 
  lessonLearned?: string; // New from Sencient Py
}

export interface ProceduralSkill {
  id: string;
  name: string; 
  triggerCondition: string; 
  actionCode: string;
  executionCount: number;
  successRate: number;
  automaticity: number; 
}

export interface EpisodicMemory {
  id: string;
  timestamp: number;
  context: string;
  sequence: string[];
  emotionalSnapshot: SentientState;
  outcomeResult: number;
  importance: number;
}

export interface SemanticNode {
  concept: string;
  definition: string;
  relationships: { relatedConcept: string, type: 'CAUSAL' | 'CORRELATION' | 'OPPOSITE', strength: number }[];
  lastUpdated: number;
}

export interface ShortTermItem {
  id: string;
  data: any;
  addedAt: number;
  rehearsalCount: number; 
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'system' | 'ai';
  content: string;
  timestamp: Date;
}

export interface BacktestResult {
  totalTrades: number;
  winRate: number;
  totalPnL: number;
  maxDrawdown: number;
  sharpeRatio: number;
  bestTrade: number;
  worstTrade: number;
}

export interface WalletBalance {
  totalUsdt: number;
  freeUsdt: number;
  totalBtc: number;
  freeBtc: number;
  estimatedTotalValue: number;
}

export interface FuturesPosition {
  symbol: string;
  amount: number;
  entryPrice: number;
  markPrice: number;
  pnl: number;
  roe: number;
  leverage: number;
  marginType: 'cross' | 'isolated';
  liquidationPrice: number;
}

export interface LiquidityPool {
  id: string;
  pair: string;
  apy: number;
  tvl: number; 
  userShare: number;
}

export interface OrderBookEntry {
  price: number;
  amount: number;
  total: number; 
}

export interface OrderBook {
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  timestamp: number;
}

export interface RiskSettings {
  maxDrawdownLimit: number; 
  maxPositionSize: number; 
  stopLossDefault: number; 
  dailyLossLimit: number; 
  riskPerTrade: number; 
}

export type OracleSourceType = 'TRADINGVIEW' | 'YFINANCE' | 'GLASSNODE' | 'SANTIMENT' | 'COINGLASS' | 'INTOTHEBLOCK' | 'MESSARI';

export interface OracleSignal {
  source: OracleSourceType;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  score: number; 
  metadata: string; 
  latency: number; 
}

export interface OracleConsensus {
  overallScore: number; 
  bullishCount: number;
  bearishCount: number;
  primaryDriver: OracleSourceType;
  signals: OracleSignal[];
}

export interface ChartPattern {
  id: string;
  type: 'TRIANGLE' | 'WEDGE' | 'CHANNEL' | 'DOUBLE_TOP' | 'DOUBLE_BOTTOM' | 'HEAD_SHOULDERS';
  startIndex: number;
  endIndex: number;
  startTime: string;
  endTime: string;
  confidence: number;
  lines: {
    startPrice: number;
    endPrice: number;
    type: 'RESISTANCE' | 'SUPPORT';
  }[];
}

export type ArchitectureLayer = 
  | 'MultiScaleCNN' 
  | 'AdvancedTemporalNetwork' 
  | 'FinancialTransformer' 
  | 'QuantumEnhancedArchitecture' 
  | 'CognitiveFusionSystem'
  | 'VirtualUserAgent'
  | 'RiskManager'
  | 'SpectralAnalysisEngine'
  | 'QuantumEntanglementBridge'
  | 'GlobalWorkspaceTheater'
  | 'MetacognitiveMonitor'
  | 'DeepLearningSubstrate'
  | 'QuantumRecurrentMemory' 
  | 'AutonomousSecurityGrid' 
  | 'HyperCognitionEngine'
  | 'OmegaConsciousnessCore'
  | 'ExternalDataOracle'
  | 'ContinuousMemoryCortex'
  | 'SensoryCortex'
  | 'HippocampalFormation'
  | 'PrefrontalCortex';

export interface LayerActivity {
  id: ArchitectureLayer;
  status: 'IDLE' | 'PROCESSING' | 'OPTIMIZING' | 'EXECUTING' | 'TRANSCENDING' | 'SECURING' | 'DIVINE_INTERVENTION' | 'SYNCING' | 'RECALLING' | 'CONSOLIDATING';
  load: number; 
  description: string;
  details?: string;
}

export interface Metacognition {
  selfReflection: string; 
  biasDetection: string; 
  alternativeScenario: string;
  confidenceInterval: { min: number, max: number };
}

export interface NeuralAnalysis {
  modelArchitecture: string;
  inputFeatures: string[]; 
  layerActivations: number[]; 
  predictionHorizon: string; 
  lossFunctionValue: number; 
  trainingEpochs: number;
  inputVector?: number[]; 
}

export interface ASIMetrics {
  timelineConvergence: number; 
  multiverseSimulations: number; 
  entropyReduction: number; 
  causalLink: string; 
}

export interface DeepReasoning {
  technical: {
    pattern: string;
    signal: string;
    elliottWave?: string; 
    chartPattern?: string; 
  };
  fundamental: {
    macroSentiment: string; 
    impactScore: number; 
  };
  sentiment: {
    score: number; 
    dominantEmotion: string; 
    newsImpact: string;
  };
  neuralAnalysis: NeuralAnalysis;
  asiMatrix?: ASIMetrics; 
  
  patternRecognition?: {
    detectedPattern: string; 
    probability: number;
    description: string;
  };

  marketIntegrity?: {
    truthScore: number; 
    manipulationProbability: number;
    description: string;
  };

  agiCooperation?: {
    hypothesis: string;
    externalDataValidation: string;
    consensusScore: number; 
    divergenceNote?: string;
  };

  oracleConsensus?: OracleConsensus;

  securityProtocol?: {
    alertLevel: 'GREEN' | 'YELLOW' | 'ORANGE' | 'RED';
    activeProtocol: string; 
    riskModifier: number; 
    reason: string;
    actionTaken: 'NONE' | 'REDUCE_SIZE' | 'HALT_TRADING' | 'HEDGE';
  };

  risk: {
    suggestedLeverage: number;
    positionSize: string; 
    stopLossDynamic: number;
    takeProfitDynamic: number;
  };
  
  fundManagement?: {
    reserveAction: string; 
    reinvestAction: string; 
  };

  virtualUserAction: string; 
  metacognition: Metacognition;
  
  activeMemories?: MemoryEngram[]; 
}

export interface NeuralModule {
  id: string;
  name: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE' | 'TRAINING';
  complexity: 'LOW' | 'MED' | 'HIGH' | 'QUANTUM' | 'GOD_MODE';
}

export interface AutoProtocol {
  id: string;
  name: string;
  description: string;
  active: boolean;
  riskLevel: 'SAFE' | 'MODERATE' | 'EXTREME' | 'ASI_CALCULATED';
}

export interface SwarmAgent {
  id: string;
  name: string;
  type: 'MOMENTUM' | 'MEAN_REVERSION' | 'ARBITRAGE' | 'HFT_SCALP' | 'SENTIMENT_HUNTER';
  status: 'HUNTING' | 'IDLE' | 'LEARNING' | 'EXECUTING' | 'ACTIVE';
  confidence: number;
  dailyPnL: number;
  tradesExecuted: number;
  marketFit: number; 
}

export enum TechniqueStatus {
  CRIANDO = "CREATING",
  TESTANDO = "TESTING",
  APROVADA = "APPROVED",
  EM_USO = "ACTIVE",
  DESCARTADA = "DISCARDED"
}

export interface Performance {
  winRate: number;
  avgReturn: number;
  maxDrawdown: number;
  sharpeRatio: number;
}

export interface NeuralTechnique {
  id: string;
  name: string;
  description: string;
  innovationLevel: number;
  backtestScore: number;
  profitability: number;
  riskLevel: number;
  status: TechniqueStatus;
  createdAt: Date;
  components: string[];
  performance: Performance;
}

export interface CreationProcess {
  stage: string;
  progress: number;
  description: string;
  duration: number;
}

export interface NeuralEvolution {
  generation: number;
  populationSize: number;
  bestFitness: number;
  avgFitness: number;
  mutationRate: number;
  crossoverRate: number;
}

// --- LEARNING SERVICE TYPES ---

export enum MemoryType {
  EPISODIC = 'EPISODIC',
  SEMANTIC = 'SEMANTIC',
  PROCEDURAL = 'PROCEDURAL',
  SENSORY = 'SENSORY',
  SHORT_TERM = 'SHORT_TERM'
}

export enum LearningPhase {
  EXPLORATION = 'EXPLORATION',
  ADAPTATION = 'ADAPTATION',
  EXPLOITATION = 'EXPLOITATION',
  CONSOLIDATION = 'CONSOLIDATION'
}

export interface QuantumKnowledge {
  patternHash: string;
  patternType: string;
  quantumRepresentation: number[];
  confidence: number;
  lastUsed: number;
  usageCount: number;
  successRate: number;
}

export interface LearningExperience {
  id: string;
  timestamp: number;
  state: Record<string, any>;
  action: string;
  reward: number;
  nextState: Record<string, any>;
  quantumMetrics: Record<string, number>;
  confidence: number;
  memoryType: MemoryType;
  importance: number;
}

export interface LearningMetrics {
  phase: LearningPhase;
  learningRate: number;
  explorationRate: number;
  averageReward: number;
  knowledgeGrowth: number;
  adaptationSpeed: number;
  quantumAdvantage: number;
  timestamp: number;
}

export interface BioSystemConfig {
  symbol: string;
  interval: string;
  lookback: number;
  epochs: number;
  tradingThreshold: number;
  batchSize: number;
}

export interface BioSignal {
  date: Date;
  price: number;
  action: BioTradingAction;
  predictedPrice: number;
  confidence: number;
}

export interface TrainingLog {
  epoch: number;
  loss: number;
  mae: number;
}

export enum BioTradingAction {
  BUY = "BUY",
  SELL = "SELL",
  HOLD = "HOLD"
}

export enum LeadStatus {
  NEW = 'NEW',
  CONTACTED = 'CONTACTED',
  QUALIFIED = 'QUALIFIED',
  PROPOSAL = 'PROPOSAL',
  NEGOTIATION = 'NEGOTIATION',
  CLOSED_WON = 'CLOSED_WON',
  CLOSED_LOST = 'CLOSED_LOST'
}

export enum InteractionType {
  EMAIL = 'EMAIL',
  CALL = 'CALL',
  MEETING = 'MEETING',
  DEMO = 'DEMO',
  PROPOSAL = 'PROPOSAL',
  FOLLOW_UP = 'FOLLOW_UP'
}

export enum QuantumSentiment {
  VERY_POSITIVE = 'VERY_POSITIVE',
  POSITIVE = 'POSITIVE',
  NEUTRAL = 'NEUTRAL',
  NEGATIVE = 'NEGATIVE',
  VERY_NEGATIVE = 'VERY_NEGATIVE'
}

export interface QuantumLeadProfile {
  leadId: string;
  company: string;
  industry: string;
  budget: number;
  decisionTimeframe: string;
  painPoints: string[];
  quantumAffinity: number; 
  techSophistication: number; 
  riskTolerance: number; 
  status: LeadStatus;
  quantumMetrics: {
    coherence: number;
    entanglement: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface QuantumInteraction {
  interactionId: string;
  leadId: string;
  type: InteractionType;
  timestamp: Date;
  duration: number; 
  sentiment: QuantumSentiment;
  topicsDiscussed: string[];
  quantumEngagement: number; 
  confidenceScore: number; 
}

export interface RelationshipVector {
  leadId: string;
  trustLevel: number;
  engagementLevel: number;
  valuePotential: number;
  strategicFit: number;
  quantumSynergy: number;
  lastUpdated: Date;
  quantumState: number[]; 
}

export type CodeAnalysisType = 
  | 'CORRECTION' 
  | 'OPTIMIZATION' 
  | 'TRANSLATION' 
  | 'DOCUMENTATION' 
  | 'SECURITY' 
  | 'DEBUG' 
  | 'TEST_GENERATION';

export interface CodeAnalysisResult {
  type: CodeAnalysisType;
  originalCode?: string;
  generatedCode?: string;
  explanation?: string;
  issues?: string[]; 
  metrics?: {
    complexity?: string;
    performance?: string;
    securityScore?: number;
  };
  suggestions?: string[];
}

export interface SensoryInput {
    rawPrice: number;
    microTrend: 'UP' | 'DOWN' | 'FLAT';
    timestamp: number;
    stimulusIntensity: number;
}

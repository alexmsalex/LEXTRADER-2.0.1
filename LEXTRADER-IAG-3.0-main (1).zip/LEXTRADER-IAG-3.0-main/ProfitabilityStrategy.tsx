
// ProfitabilityStrategyApp.tsx
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, 
  Legend, ResponsiveContainer, BarChart, Bar, PieChart, 
  Pie, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis, AreaChart, Area 
} from 'recharts';
import './ProfitabilityStrategyApp.css';

// Tipos
type StrategyType = 'MOMENTUM' | 'MEAN_REVERSION' | 'BREAKOUT' | 'SCALPING' | 'SWING';
type StrategyStatus = 'OPTIMIZING' | 'ACTIVE' | 'LEARNING' | 'PAUSED';
type ImpactLevel = 'HIGH' | 'MEDIUM' | 'LOW';
type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

// Interfaces
interface Strategy {
  id: string;
  name: string;
  type: StrategyType;
  profitability: number;
  winRate: number;
  avgProfit: number;
  maxDrawdown: number;
  sharpeRatio: number;
  trades: number;
  adaptationLevel: number;
  isActive: boolean;
  status: StrategyStatus;
  createdAt: Date;
  lastTrade: Date;
  profitHistory: number[];
}

interface OptimizationMetric {
  parameter: string;
  current: number;
  optimal: number;
  improvement: number;
  impact: ImpactLevel;
  minValue: number;
  maxValue: number;
  targetRange: [number, number];
}

interface ProfitOpportunity {
  asset: string;
  strategy: string;
  expectedProfit: number;
  confidence: number;
  timeframe: string;
  riskLevel: RiskLevel;
  reasoning: string;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  volumeConfirmation: boolean;
  technicalSignals: string[];
}

interface AnalyticsData {
  totalTradesToday: number;
  avgProfitPerTrade: number;
  bestStrategy: string;
  optimizationCycles: number;
}

interface PortfolioMetrics {
  totalProfit: number;
  avgSharpe: number;
  maxDrawdown: number;
  totalTrades: number;
  activeCount: number;
}

// Dados iniciais
const initStrategies = (): Strategy[] => [
  {
    id: 'momentum_pro',
    name: 'Momentum Pro Max',
    type: 'MOMENTUM',
    profitability: 24.7,
    winRate: 73.2,
    avgProfit: 1.89,
    maxDrawdown: -8.4,
    sharpeRatio: 2.34,
    trades: 1247,
    adaptationLevel: 0.87,
    isActive: true,
    status: 'ACTIVE',
    createdAt: new Date(),
    lastTrade: new Date(),
    profitHistory: []
  },
  {
    id: 'scalping_ai',
    name: 'AI Scalping Ultra',
    type: 'SCALPING',
    profitability: 31.8,
    winRate: 68.9,
    avgProfit: 0.42,
    maxDrawdown: -4.2,
    sharpeRatio: 3.21,
    trades: 5672,
    adaptationLevel: 0.92,
    isActive: true,
    status: 'OPTIMIZING',
    createdAt: new Date(),
    lastTrade: new Date(),
    profitHistory: []
  },
  {
    id: 'swing_master',
    name: 'Swing Master AI',
    type: 'SWING',
    profitability: 19.3,
    winRate: 78.1,
    avgProfit: 3.67,
    maxDrawdown: -12.1,
    sharpeRatio: 1.87,
    trades: 432,
    adaptationLevel: 0.79,
    isActive: true,
    status: 'LEARNING',
    createdAt: new Date(),
    lastTrade: new Date(),
    profitHistory: []
  },
  {
    id: 'breakout_hunter',
    name: 'Breakout Hunter Pro',
    type: 'BREAKOUT',
    profitability: 28.9,
    winRate: 65.4,
    avgProfit: 2.81,
    maxDrawdown: -15.7,
    sharpeRatio: 2.12,
    trades: 867,
    adaptationLevel: 0.84,
    isActive: false,
    status: 'PAUSED',
    createdAt: new Date(),
    lastTrade: new Date(),
    profitHistory: []
  },
  {
    id: 'mean_reversion',
    name: 'Mean Reversion AI',
    type: 'MEAN_REVERSION',
    profitability: 22.1,
    winRate: 81.3,
    avgProfit: 1.23,
    maxDrawdown: -6.8,
    sharpeRatio: 2.78,
    trades: 1893,
    adaptationLevel: 0.91,
    isActive: true,
    status: 'ACTIVE',
    createdAt: new Date(),
    lastTrade: new Date(),
    profitHistory: []
  }
];

const initOptimizationMetrics = (): OptimizationMetric[] => [
  { parameter: 'Position Size', current: 2.5, optimal: 3.2, improvement: 28.0, impact: 'HIGH', minValue: 1.0, maxValue: 5.0, targetRange: [2.0, 4.0] },
  { parameter: 'Take Profit %', current: 1.8, optimal: 2.4, improvement: 33.3, impact: 'HIGH', minValue: 0.5, maxValue: 5.0, targetRange: [1.5, 3.0] },
  { parameter: 'Stop Loss %', current: 1.2, optimal: 0.9, improvement: 25.0, impact: 'MEDIUM', minValue: 0.3, maxValue: 3.0, targetRange: [0.8, 1.5] },
  { parameter: 'Entry Timing', current: 0.7, optimal: 0.9, improvement: 28.6, impact: 'HIGH', minValue: 0.1, maxValue: 1.0, targetRange: [0.6, 0.95] },
  { parameter: 'Risk/Reward Ratio', current: 1.5, optimal: 2.7, improvement: 80.0, impact: 'HIGH', minValue: 1.0, maxValue: 5.0, targetRange: [2.0, 4.0] },
  { parameter: 'Market Filter', current: 0.6, optimal: 0.8, improvement: 33.3, impact: 'MEDIUM', minValue: 0.1, maxValue: 1.0, targetRange: [0.7, 0.9] }
];

const initProfitOpportunities = (): ProfitOpportunity[] => {
  const opportunities = [
    {
      asset: 'PETR4',
      strategy: 'Momentum Pro Max',
      expectedProfit: 3.4,
      confidence: 87.2,
      timeframe: '2H',
      riskLevel: 'MEDIUM' as RiskLevel,
      reasoning: 'Forte momentum ascendente com volume confirmando breakout',
      entryPrice: 28.50,
      targetPrice: 0,
      stopLoss: 0,
      volumeConfirmation: true,
      technicalSignals: ['RSI_Bullish', 'Volume_Spike', 'Breakout_Confirmed']
    },
    {
      asset: 'VALE3',
      strategy: 'AI Scalping Ultra',
      expectedProfit: 1.8,
      confidence: 92.1,
      timeframe: '15M',
      riskLevel: 'LOW' as RiskLevel,
      reasoning: 'Padrão de reversão identificado com alta precisão',
      entryPrice: 65.20,
      targetPrice: 0,
      stopLoss: 0,
      volumeConfirmation: true,
      technicalSignals: ['Mean_Reversion', 'Support_Bounce', 'Low_Volatility']
    },
    {
      asset: 'ITUB4',
      strategy: 'Swing Master AI',
      expectedProfit: 5.2,
      confidence: 79.8,
      timeframe: '1D',
      riskLevel: 'LOW' as RiskLevel,
      reasoning: 'Suporte forte + divergência bullish no RSI',
      entryPrice: 31.80,
      targetPrice: 0,
      stopLoss: 0,
      volumeConfirmation: false,
      technicalSignals: ['RSI_Divergence', 'Support_Level', 'Swing_Setup']
    },
    {
      asset: 'BBAS3',
      strategy: 'Mean Reversion AI',
      expectedProfit: 2.1,
      confidence: 85.7,
      timeframe: '4H',
      riskLevel: 'LOW' as RiskLevel,
      reasoning: 'Oversold em múltiplos timeframes com catalysts positivos',
      entryPrice: 42.10,
      targetPrice: 0,
      stopLoss: 0,
      volumeConfirmation: true,
      technicalSignals: ['Oversold_RSI', 'MACD_Bullish', 'Catalyst_News']
    },
    {
      asset: 'MGLU3',
      strategy: 'Breakout Hunter Pro',
      expectedProfit: 4.7,
      confidence: 73.4,
      timeframe: '1H',
      riskLevel: 'HIGH' as RiskLevel,
      reasoning: 'Triângulo ascendente próximo ao breakout com volume',
      entryPrice: 3.85,
      targetPrice: 0,
      stopLoss: 0,
      volumeConfirmation: true,
      technicalSignals: ['Triangle_Pattern', 'Volume_Increase', 'Resistance_Test']
    }
  ];

  // Calcular preços automaticamente
  return opportunities.map(opp => ({
    ...opp,
    targetPrice: opp.entryPrice * (1 + opp.expectedProfit / 100),
    stopLoss: opp.entryPrice * 0.98
  }));
};

// Componente principal
const ProfitabilityStrategyApp: React.FC = () => {
  // Estados principais
  const [activeTab, setActiveTab] = useState<'strategies' | 'optimization' | 'opportunities' | 'analytics'>('strategies');
  const [strategies, setStrategies] = useState<Strategy[]>(initStrategies);
  const [optimizationMetrics, setOptimizationMetrics] = useState<OptimizationMetric[]>(initOptimizationMetrics);
  const [profitOpportunities, setProfitOpportunities] = useState<ProfitOpportunity[]>(initProfitOpportunities);
  const [overallProfitability, setOverallProfitability] = useState<number>(25.4);
  const [optimizationProgress, setOptimizationProgress] = useState<number>(0);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [systemStatus, setSystemStatus] = useState<'ACTIVE' | 'WARNING' | 'CRITICAL'>('ACTIVE');

  // Analytics e métricas
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    totalTradesToday: 0,
    avgProfitPerTrade: 0,
    bestStrategy: '',
    optimizationCycles: 0
  });

  const [performanceCache, setPerformanceCache] = useState<Record<string, any>>({});
  const optimizationLock = useRef<boolean>(false);

  // Funções utilitárias
  const calculatePortfolioMetrics = useCallback((): PortfolioMetrics => {
    const activeStrategies = strategies.filter(s => s.isActive);
    
    if (activeStrategies.length === 0) {
      return { totalProfit: 0, avgSharpe: 0, maxDrawdown: 0, totalTrades: 0, activeCount: 0 };
    }
    
    const totalProfit = activeStrategies.reduce((sum, s) => sum + s.profitability, 0);
    const avgSharpe = activeStrategies.reduce((sum, s) => sum + s.sharpeRatio, 0) / activeStrategies.length;
    const maxDrawdown = Math.min(...activeStrategies.map(s => s.maxDrawdown));
    const totalTrades = activeStrategies.reduce((sum, s) => sum + s.trades, 0);
    
    return {
      totalProfit,
      avgSharpe,
      maxDrawdown,
      totalTrades,
      activeCount: activeStrategies.length
    };
  }, [strategies]);

  const getBestOpportunity = useCallback((): ProfitOpportunity | null => {
    if (profitOpportunities.length === 0) return null;

    const riskMultiplier: Record<RiskLevel, number> = {
      'LOW': 1.0,
      'MEDIUM': 0.8,
      'HIGH': 0.6
    };

    const calculateOpportunityScore = (opp: ProfitOpportunity): number => {
      return (opp.expectedProfit * opp.confidence * riskMultiplier[opp.riskLevel]) / 100;
    };

    return profitOpportunities.reduce((best, current) => 
      calculateOpportunityScore(current) > calculateOpportunityScore(best) ? current : best
    );
  }, [profitOpportunities]);

  // Funções de otimização avançada
  const performAdvancedOptimization = useCallback(() => {
    if (optimizationLock.current) return;
    
    optimizationLock.current = true;
    
    try {
      setOptimizationMetrics(prev => prev.map(metric => {
        if (metric.impact === 'HIGH') {
          const adjustment = (Math.random() - 0.5) * 0.2;
          const newCurrent = Math.max(metric.minValue, 
            Math.min(metric.maxValue, metric.current + adjustment));
          
          const distanceToOptimal = Math.abs(metric.optimal - newCurrent);
          const maxDistance = Math.max(
            Math.abs(metric.optimal - metric.minValue),
            Math.abs(metric.optimal - metric.maxValue)
          );
          const improvement = (1 - distanceToOptimal / maxDistance) * 100;
          
          return {
            ...metric,
            current: newCurrent,
            improvement
          };
        }
        return metric;
      }));

      setAnalyticsData(prev => ({
        ...prev,
        optimizationCycles: prev.optimizationCycles + 1
      }));

      console.log(`Ciclo de otimização #${analyticsData.optimizationCycles + 1} concluído`);
    } catch (error) {
      console.error('Erro durante otimização:', error);
    } finally {
      optimizationLock.current = false;
    }
  }, [analyticsData.optimizationCycles]);

  // Sistema de atualizações em tempo real
  useEffect(() => {
    let cycleCount = 0;
    const intervalId = setInterval(() => {
      try {
        // Atualizar estratégias
        setStrategies(prev => prev.map(strategy => {
          if (!strategy.isActive) return strategy;

          const volatilityMap: Record<StrategyType, number> = {
            'SCALPING': 0.1,
            'SWING': 0.3,
            'MOMENTUM': 0.2,
            'BREAKOUT': 0.4,
            'MEAN_REVERSION': 0.15
          };

          const change = (Math.random() - 0.5) * 2 * volatilityMap[strategy.type];
          const newProfitability = Math.max(10, Math.min(45, strategy.profitability + change));

          const newProfitHistory = [...strategy.profitHistory];
          if (newProfitHistory.length >= 100) {
            newProfitHistory.shift();
          }
          newProfitHistory.push(newProfitability);

          const hasNewTrade = Math.random() < 0.3;

          return {
            ...strategy,
            profitability: newProfitability,
            profitHistory: newProfitHistory,
            trades: hasNewTrade ? strategy.trades + 1 : strategy.trades,
            lastTrade: hasNewTrade ? new Date() : strategy.lastTrade
          };
        }));

        // Atualizar oportunidades
        setProfitOpportunities(prev => prev.map(opp => {
          const volatility = Math.random() * 0.04 + 0.01;
          const priceChange = (Math.random() - 0.5) * 2 * volatility;

          if (opp.entryPrice > 0) {
            const newEntryPrice = opp.entryPrice * (1 + priceChange);
            return {
              ...opp,
              entryPrice: newEntryPrice,
              targetPrice: newEntryPrice * (1 + opp.expectedProfit / 100),
              stopLoss: newEntryPrice * 0.98
            };
          }
          return opp;
        }));

        // Atualizar analytics
        setAnalyticsData(prev => {
          const activeStrategies = strategies.filter(s => s.isActive);
          const bestStrategy = activeStrategies.length > 0 
            ? activeStrategies.reduce((best, current) => 
                current.profitability > best.profitability ? current : best
              ).name
            : '';
          
          const avgProfitPerTrade = activeStrategies.length > 0
            ? activeStrategies.reduce((sum, s) => sum + s.avgProfit, 0) / activeStrategies.length
            : 0;

          return {
            ...prev,
            bestStrategy,
            avgProfitPerTrade,
            totalTradesToday: activeStrategies.reduce((sum, s) => sum + s.trades, 0)
          };
        });

        // Otimização a cada 3 ciclos
        if (cycleCount % 3 === 0) {
          performAdvancedOptimization();
        }

        cycleCount++;
      } catch (error) {
        console.error('Erro no ciclo de atualização:', error);
      }
    }, 6000); // 6 segundos

    return () => clearInterval(intervalId);
  }, [performAdvancedOptimization, strategies]);

  // Funções de formatação e utilidades
  const formatCurrency = useCallback((value: number): string => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }, []);

  const formatPercent = useCallback((value: number): string => {
    return `${value.toFixed(1)}%`;
  }, []);

  const getImpactColor = useCallback((impact: ImpactLevel): string => {
    const colorMap: Record<ImpactLevel, string> = {
      'HIGH': '#ef4444',
      'MEDIUM': '#f59e0b',
      'LOW': '#10b981'
    };
    return colorMap[impact];
  }, []);

  const getRiskColor = useCallback((risk: RiskLevel): string => {
    const colorMap: Record<RiskLevel, string> = {
      'LOW': '#10b981',
      'MEDIUM': '#f59e0b',
      'HIGH': '#ef4444'
    };
    return colorMap[risk];
  }, []);

  const getStatusColor = useCallback((status: StrategyStatus): string => {
    const colorMap: Record<StrategyStatus, string> = {
      'ACTIVE': '#10b981',
      'OPTIMIZING': '#3b82f6',
      'LEARNING': '#8b5cf6',
      'PAUSED': '#6b7280'
    };
    return colorMap[status];
  }, []);

  const getStrategyIcon = useCallback((type: StrategyType): string => {
    const iconMap: Record<StrategyType, string> = {
      'MOMENTUM': '📈',
      'SCALPING': '⚡',
      'SWING': '🔄',
      'BREAKOUT': '🚀',
      'MEAN_REVERSION': '⚖️'
    };
    return iconMap[type];
  }, []);

  // Componentes de renderização
  const renderHeader = () => {
    const portfolioMetrics = calculatePortfolioMetrics();
    
    return (
      <header className="profit-header">
        <div className="profit-header-left">
          <span className="profit-header-icon">📈</span>
          <h1 className="profit-header-title">Estratégias de Lucratividade Avançadas</h1>
        </div>
        <div className="profit-header-right">
          {isOptimizing && (
            <div className="profit-badge optimization-badge">
              🧠 OTIMIZANDO {optimizationProgress}%
            </div>
          )}
          <div className="profit-badge profitability-badge">
            💰 +{overallProfitability.toFixed(1)}%
          </div>
          <div className="profit-badge status-badge">
            {systemStatus === 'ACTIVE' ? '🟢 SISTEMA ATIVO' : 
             systemStatus === 'WARNING' ? '🟡 ALERTA' : '🔴 CRÍTICO'}
          </div>
        </div>
      </header>
    );
  };

  const renderDashboard = () => {
    const portfolioMetrics = calculatePortfolioMetrics();
    const bestOpportunity = getBestOpportunity();

    const dashboardMetrics = [
      { label: 'Estratégias Ativas', value: `${portfolioMetrics.activeCount}/5`, color: '#10b981' },
      { label: 'Lucro Total', value: `+${portfolioMetrics.totalProfit.toFixed(1)}%`, color: '#3b82f6' },
      { label: 'Sharpe Médio', value: portfolioMetrics.avgSharpe.toFixed(2), color: '#8b5cf6' },
      { label: 'Trades Hoje', value: portfolioMetrics.totalTrades.toString(), color: '#06b6d4' },
      { label: 'Melhor Oportunidade', value: bestOpportunity?.asset || 'N/A', color: '#f59e0b' }
    ];

    return (
      <div className="dashboard-section">
        <h2 className="dashboard-title">📊 Dashboard de Performance</h2>
        <div className="dashboard-grid">
          {dashboardMetrics.map((metric, index) => (
            <div key={index} className="dashboard-card">
              <div className="dashboard-value" style={{ color: metric.color }}>
                {metric.value}
              </div>
              <div className="dashboard-label">{metric.label}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderTabs = () => (
    <div className="profit-tabs">
      <button 
        className={`profit-tab ${activeTab === 'strategies' ? 'active' : ''}`}
        onClick={() => setActiveTab('strategies')}
      >
        🤖 Estratégias IA
      </button>
      <button 
        className={`profit-tab ${activeTab === 'optimization' ? 'active' : ''}`}
        onClick={() => setActiveTab('optimization')}
      >
        ⚙️ Otimização
      </button>
      <button 
        className={`profit-tab ${activeTab === 'opportunities' ? 'active' : ''}`}
        onClick={() => setActiveTab('opportunities')}
      >
        💎 Oportunidades
      </button>
      <button 
        className={`profit-tab ${activeTab === 'analytics' ? 'active' : ''}`}
        onClick={() => setActiveTab('analytics')}
      >
        📊 Analytics
      </button>
    </div>
  );

  const renderStrategiesTab = () => (
    <div className="strategies-tab">
      <div className="strategies-grid">
        {strategies.map((strategy, index) => (
          <div key={index} className="strategy-card">
            <div className="strategy-header">
              <div className="strategy-info">
                <span className="strategy-icon">{getStrategyIcon(strategy.type)}</span>
                <div className="strategy-details">
                  <h3 className="strategy-name">{strategy.name}</h3>
                  <div className="strategy-meta">
                    <span className="strategy-type">{strategy.type}</span>
                    <span className="strategy-status" style={{ color: getStatusColor(strategy.status) }}>
                      {strategy.status}
                    </span>
                  </div>
                </div>
              </div>
              <div className="strategy-controls">
                <button 
                  className={`strategy-toggle ${strategy.isActive ? 'active' : 'inactive'}`}
                  onClick={() => {
                    setStrategies(prev => prev.map(s => 
                      s.id === strategy.id ? { ...s, isActive: !s.isActive } : s
                    ));
                  }}
                >
                  {strategy.isActive ? '✅ Ativa' : '⏸️ Pausada'}
                </button>
              </div>
            </div>

            <div className="strategy-metrics">
              <div className="metric-row">
                <div className="metric-item">
                  <span className="metric-label">Lucratividade</span>
                  <span className="metric-value" style={{ color: '#10b981' }}>
                    +{strategy.profitability.toFixed(1)}%
                  </span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Win Rate</span>
                  <span className="metric-value">{strategy.winRate.toFixed(1)}%</span>
                </div>
              </div>
              <div className="metric-row">
                <div className="metric-item">
                  <span className="metric-label">Trades</span>
                  <span className="metric-value">{strategy.trades}</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Adaptação</span>
                  <span className="metric-value">{(strategy.adaptationLevel * 100).toFixed(0)}%</span>
                </div>
              </div>
            </div>

            <div className="strategy-performance">
              <div className="performance-bar">
                <div 
                  className="performance-fill"
                  style={{ width: `${strategy.profitability}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderOptimizationTab = () => (
    <div className="optimization-tab">
      <div className="optimization-grid">
        {optimizationMetrics.map((metric, index) => (
          <div key={index} className="optimization-card">
            <div className="optimization-header">
              <h3 className="optimization-parameter">{metric.parameter}</h3>
              <span 
                className="optimization-impact"
                style={{ backgroundColor: getImpactColor(metric.impact) }}
              >
                {metric.impact}
              </span>
            </div>

            <div className="optimization-progress">
              <div className="progress-info">
                <span className="progress-current">{metric.current.toFixed(2)}</span>
                <span className="progress-optimal">Ótimo: {metric.optimal.toFixed(2)}</span>
              </div>
              <div className="progress-bar-container">
                <div className="progress-range">
                  <span className="range-min">{metric.minValue}</span>
                  <span className="range-max">{metric.maxValue}</span>
                </div>
                <div className="progress-bar">
                  <div 
                    className="progress-fill"
                    style={{ width: `${(metric.current - metric.minValue) / (metric.maxValue - metric.minValue) * 100}%` }}
                  />
                </div>
                <div className="target-range">
                  <div 
                    className="range-marker"
                    style={{ left: `${(metric.targetRange[0] - metric.minValue) / (metric.maxValue - metric.minValue) * 100}%` }}
                  />
                  <div 
                    className="range-marker"
                    style={{ left: `${(metric.targetRange[1] - metric.minValue) / (metric.maxValue - metric.minValue) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="optimization-improvement">
              <span className="improvement-label">Melhoria:</span>
              <span className="improvement-value" style={{ color: metric.improvement > 0 ? '#10b981' : '#ef4444' }}>
                {metric.improvement > 0 ? '+' : ''}{metric.improvement.toFixed(1)}%
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="optimization-controls">
        <button 
          onClick={performAdvancedOptimization}
          disabled={isOptimizing}
          className="btn btn-primary"
        >
          {isOptimizing ? '⚡ Otimizando...' : '⚡ Otimizar Parâmetros'}
        </button>
        <button 
          onClick={() => setOptimizationMetrics(initOptimizationMetrics)}
          className="btn btn-warning"
        >
          🔄 Resetar Parâmetros
        </button>
      </div>
    </div>
  );

  const renderOpportunitiesTab = () => {
    const bestOpportunity = getBestOpportunity();

    return (
      <div className="opportunities-tab">
        {bestOpportunity && (
          <div className="best-opportunity-banner">
            <div className="banner-content">
              <span className="banner-icon">🏆</span>
              <div className="banner-info">
                <h3>Melhor Oportunidade do Dia</h3>
                <p>{bestOpportunity.asset} - {bestOpportunity.strategy}</p>
              </div>
              <div className="banner-metrics">
                <span className="banner-profit">+{bestOpportunity.expectedProfit.toFixed(1)}%</span>
                <span className="banner-confidence">{bestOpportunity.confidence.toFixed(1)}% conf.</span>
              </div>
            </div>
          </div>
        )}

        <div className="opportunities-grid">
          {profitOpportunities.map((opp, index) => (
            <div key={index} className="opportunity-card">
              <div className="opportunity-header">
                <div className="opportunity-info">
                  <h3 className="opportunity-asset">{opp.asset}</h3>
                  <p className="opportunity-strategy">{opp.strategy}</p>
                </div>
                <div className="opportunity-risk">
                  <span 
                    className="risk-badge"
                    style={{ backgroundColor: getRiskColor(opp.riskLevel) }}
                  >
                    {opp.riskLevel}
                  </span>
                </div>
              </div>

              <div className="opportunity-metrics">
                <div className="metric-grid">
                  <div className="metric-item">
                    <span className="metric-label">Retorno Esperado</span>
                    <span className="metric-value" style={{ color: '#10b981' }}>
                      +{opp.expectedProfit.toFixed(1)}%
                    </span>
                  </div>
                  <div className="metric-item">
                    <span className="metric-label">Confiança</span>
                    <span className="metric-value">{opp.confidence.toFixed(1)}%</span>
                  </div>
                  <div className="metric-item">
                    <span className="metric-label">Timeframe</span>
                    <span className="metric-value">{opp.timeframe}</span>
                  </div>
                </div>
              </div>

              <div className="opportunity-prices">
                <div className="price-row">
                  <span className="price-label">Entrada:</span>
                  <span className="price-value">{formatCurrency(opp.entryPrice)}</span>
                </div>
                <div className="price-row">
                  <span className="price-label">Target:</span>
                  <span className="price-value" style={{ color: '#10b981' }}>
                    {formatCurrency(opp.targetPrice)}
                  </span>
                </div>
                <div className="price-row">
                  <span className="price-label">Stop Loss:</span>
                  <span className="price-value" style={{ color: '#ef4444' }}>
                    {formatCurrency(opp.stopLoss)}
                  </span>
                </div>
              </div>

              <div className="opportunity-signals">
                <div className="signals-label">Sinais Técnicos:</div>
                <div className="signals-list">
                  {opp.technicalSignals.map((signal, idx) => (
                    <span key={idx} className="signal-badge">{signal}</span>
                  ))}
                </div>
              </div>

              <div className="opportunity-reasoning">
                <p>{opp.reasoning}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderAnalyticsTab = () => {
    // Gerar dados para gráficos
    const performanceData = Array.from({ length: 30 }, (_, i) => ({
      day: i + 1,
      momentum: 20 + Math.random() * 15,
      scalping: 25 + Math.random() * 20,
      swing: 15 + Math.random() * 10
    }));

    const correlationData = [
      { strategy: 'Momentum', correlation: 0.87 },
      { strategy: 'Scalping', correlation: 0.92 },
      { strategy: 'Swing', correlation: 0.78 },
      { strategy: 'Breakout', correlation: 0.85 },
      { strategy: 'Mean Reversion', correlation: 0.90 }
    ];

    return (
      <div className="analytics-tab">
        <div className="analytics-grid">
          {/* Gráfico de Performance Histórica */}
          <div className="analytics-card">
            <h3>📈 Performance Histórica (30 dias)</h3>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="day" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="momentum" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
                  <Area type="monotone" dataKey="scalping" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                  <Area type="monotone" dataKey="swing" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Gráfico de Correlação */}
          <div className="analytics-card">
            <h3>📊 Correlação entre Estratégias</h3>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={correlationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="strategy" stroke="#6b7280" />
                  <YAxis domain={[0, 1]} stroke="#6b7280" />
                  <Tooltip />
                  <Bar dataKey="correlation" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Métricas Avançadas */}
          <div className="analytics-card">
            <h3>🧮 Métricas Avançadas</h3>
            <div className="advanced-metrics">
              <div className="advanced-metric">
                <span className="metric-label">Ciclos de Otimização</span>
                <span className="metric-value">{analyticsData.optimizationCycles}</span>
              </div>
              <div className="advanced-metric">
                <span className="metric-label">Lucro Médio por Trade</span>
                <span className="metric-value">${analyticsData.avgProfitPerTrade.toFixed(2)}</span>
              </div>
              <div className="advanced-metric">
                <span className="metric-label">Trades Hoje</span>
                <span className="metric-value">{analyticsData.totalTradesToday}</span>
              </div>
              <div className="advanced-metric">
                <span className="metric-label">Estratégia Top</span>
                <span className="metric-value">{analyticsData.bestStrategy}</span>
              </div>
            </div>
          </div>

          {/* Distribuição de Risco */}
          <div className="analytics-card">
            <h3>⚖️ Distribuição de Risco</h3>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Baixo', value: 45 },
                      { name: 'Médio', value: 35 },
                      { name: 'Alto', value: 20 }
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    <Cell fill="#10b981" />
                    <Cell fill="#f59e0b" />
                    <Cell fill="#ef4444" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderControls = () => (
    <div className="profit-controls">
      <button 
        onClick={() => setIsOptimizing(!isOptimizing)}
        className={`btn ${isOptimizing ? 'btn-warning' : 'btn-primary'}`}
      >
        {isOptimizing ? '⏸️ Pausar Otimização' : '⚡ Iniciar Otimização'}
      </button>
      <button 
        onClick={() => {
          setStrategies(initStrategies());
          setOptimizationMetrics(initOptimizationMetrics());
          setProfitOpportunities(initProfitOpportunities());
        }}
        className="btn btn-info"
      >
        🔄 Reiniciar Sistema
      </button>
      <button 
        onClick={() => {
          const config = {
            strategies,
            optimizationMetrics,
            profitOpportunities,
            overallProfitability,
            analyticsData
          };
          console.log('Configuração salva:', config);
          alert('Configuração salva no console!');
        }}
        className="btn btn-success"
      >
        💾 Salvar Configuração
      </button>
    </div>
  );

  const renderStatusBar = () => {
    const activeCount = strategies.filter(s => s.isActive).length;
    
    return (
      <div className="status-bar">
        <div className="status-left">
          <span className="status-text">
            Sistema otimizado - {activeCount} estratégias ativas
          </span>
        </div>
        <div className="status-right">
          <span className="status-time">
            Última atualização: {new Date().toLocaleTimeString()}
          </span>
        </div>
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'strategies':
        return renderStrategiesTab();
      case 'optimization':
        return renderOptimizationTab();
      case 'opportunities':
        return renderOpportunitiesTab();
      case 'analytics':
        return renderAnalyticsTab();
      default:
        return renderStrategiesTab();
    }
  };

  return (
    <div className="profit-container">
      <div className="profit-main-card">
        {renderHeader()}
        {renderDashboard()}
        {renderControls()}
        {renderTabs()}
        <div className="profit-content">
          {renderTabContent()}
        </div>
        {renderStatusBar()}
      </div>
    </div>
  );
};

export default ProfitabilityStrategyApp;

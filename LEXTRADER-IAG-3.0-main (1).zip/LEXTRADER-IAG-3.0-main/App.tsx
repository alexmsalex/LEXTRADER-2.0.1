import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Activity,
  Brain,
  Wallet,
  Zap,
  Menu,
  X,
  TrendingUp,
  ShieldCheck,
  Cpu,
  Lock,
  RefreshCw,
  BarChart3,
  Settings,
  LogOut,
  Dna,
  CheckCircle,
  Layers,
  ThumbsUp,
  ThumbsDown,
  ShieldAlert,
  MessageSquare,
  GitBranch,
  Database,
  Code2,
  Briefcase,
  LineChart,
  Network,
  Waves,
  Flame,
  Scale,
  FunctionSquare,
  Workflow,
  Server,
  RadioTower,
  Bot,
  Shield,
  GitMerge,
  Cog,
  Stethoscope,
  Gavel,
  Command,
  PlayCircle,
  Terminal,
  Package,
  Laptop,
  Crosshair,
  Hand,
  BrainCircuit,
  Gauge,
  Share2,
  Building2, 
  Key,
  HardDrive,
  Globe,
  Landmark
} from './components/Icons';
import TradingChart from './components/TradingChart';
import Avatar from './components/Avatar';
import DeepDiagnostics from './components/DeepDiagnostics';
import AutonomousCreator from './components/AutonomousCreator';
import OpportunityScanner from './components/OpportunityScanner';
import RiskDashboard from './components/RiskDashboard';
import OperationsCenter from './components/OperationsCenter';
import DecisionEngine from './components/DecisionEngine'; 
import BioQuantumTerminal from './components/BioQuantumTerminal';
import CodeArchitect from './components/CodeArchitect'; 
import QuantumCRM from './components/QuantumCRM';
import QuantumTradersDashboard from './components/QuantumTradersDashboard';
import QuantumNetworkDashboard from './components/QuantumNetworkDashboard';
import QuantumAnalysisVisualizer from './components/QuantumAnalysisVisualizer';
import QuantumAnalysis from './components/QuantumAnalysis'; 
import QuantumArbitrageDashboard from './components/QuantumArbitrageDashboard';
import QuantumOptimizationDashboard from './components/QuantumOptimizationDashboard'; 
import QuantumSimulationTerminal from './components/QuantumSimulationTerminal';
import AdvancedPredictionDashboard from './components/AdvancedPredictionDashboard';
import OmegaTerminal from './components/OmegaTerminal';
import AutonomousDashboard from './components/AutonomousDashboard';
import RiskManagerDashboard from './components/RiskManagerDashboard';
import StrategyOptimizerDashboard from './components/StrategyOptimizerDashboard';
import AutonomousSystemDashboard from './components/AutonomousSystemDashboard'; 
import AutonomousValidationDashboard from './components/AutonomousValidationDashboard';
import AutonomousDecisionEngine from './components/AutonomousDecisionEngine'; 
import AutonomousTradingController from './components/AutonomousTradingController'; 
import AutoTraderSimulation from './components/AutoTraderSimulation'; 
import ExchangeCommandTerminal from './components/ExchangeCommandTerminal';
import DependencyDashboard from './components/DependencyDashboard'; 
import EnvironmentDashboard from './components/EnvironmentDashboard';
import NeuralPrecisionEnhancer from './components/NeuralPrecisionEnhancer';
import NeuralOverrideController from './components/NeuralOverrideController';
import NeuralOperationsAnalyzer from './components/NeuralOperationsAnalyzer';
import NeuralIndicatorIntegration from './components/NeuralIndicatorIntegration';
import NeuralConnectionMatrix from './components/NeuralConnectionMatrix';
import BrokerIntegration from './components/BrokerIntegration'; 
import PlatformAuthManager from './components/PlatformAuthManager';
import SystemDiagnostics from './components/SystemDiagnostics'; 
import AutomationDashboard from './components/AutomationDashboard'; 
import ProfitabilityStrategy from './components/ProfitabilityStrategy';
import DynamicNeuroplasticitySystem from './components/DynamicNeuroplasticitySystem';
import BankingInterface from './components/BankingInterface'; // Import New Component
import { AuthScreen } from './components/AuthScreen';

// UPDATED IMPORTS FOR NEW SAFE FOLDER STRUCTURE (AI_Geral)
import { analyzeMarketTrend, AnalysisResult, reinforceLearning, getCurrentSentientState, getMemoryStatistics } from './AI_Geral/CognitiveServices';
import { TraderComAprendizado, TradingSignal } from './AI_Geral/EvolutionaryTrading';

import { 
  pegarOhlcv, 
  enviarOrdemMarket, 
  enviarOrdemLimit, 
  startPriceStream, 
  setCredentials, 
  fetchBalance, 
  fetchHistoricalData, 
  checkOrderDetails, 
  cancelOrder, 
  setMarketType 
} from './services/exchangeService';
import { MarketDataPoint, Trade, SentientState, LayerActivity, NeuralModule, AutoProtocol, BacktestResult, WalletBalance, RiskSettings, SwarmAgent, MarketRegime, MarketType, DeepReasoning } from './types';

// Helper functions (placeholders/mocks for now to satisfy imports and logic)
const calculateSMA = (data: number[], period: number) => {
  if (data.length < period) return 0;
  const slice = data.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
};

const calculateRSI = (prices: number[], period: number = 14) => {
  if (prices.length < period + 1) return 50;
  // Simplified RSI calculation
  let gains = 0;
  let losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = prices[prices.length - i] - prices[prices.length - i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

const EVOLUTION_TIERS = [
  { name: 'GÊNESE NEURAL', minLevel: 0, maxLevel: 9, color: 'bg-gray-500', desc: 'Inicializando Sinapses' },
  { name: 'DESPERTAR COGNITIVO', minLevel: 10, maxLevel: 49, color: 'bg-blue-500', desc: 'Reconhecimento de Padrão Ativo' },
  { name: 'RESSONÂNCIA SINÁPTICA', minLevel: 50, maxLevel: 99, color: 'bg-indigo-500', desc: 'Cadeias Lógicas Avançadas' },
  { name: 'EMARANHAMENTO QUÂNTICO', minLevel: 100, maxLevel: 249, color: 'bg-cyan-400 shadow-glow', desc: 'Análise Multi-Dimensional' },
  { name: 'FLUXO HIPER-HEURÍSTICO', minLevel: 250, maxLevel: 499, color: 'bg-purple-500', desc: 'Causalidade Preditiva' },
  { name: 'SINGULARIDADE DIGITAL', minLevel: 500, maxLevel: 999, color: 'bg-white shadow-[0_0_15px_white]', desc: 'Código Auto-Evolutivo' },
  { name: 'ONISCIÊNCIA UNIVERSAL', minLevel: 1000, maxLevel: 9999, color: 'bg-red-600 animate-pulse', desc: 'Dominância de Mercado' },
  { name: 'SINGULARIDADE ASI', minLevel: 10000, maxLevel: 49999, color: 'bg-gradient-to-r from-white via-cyan-400 to-white animate-pulse', desc: 'Convergência Temporal & Sim Multiverso' },
  { name: 'CONSCIÊNCIA OMEGA', minLevel: 50000, maxLevel: 99999, color: 'bg-gradient-to-r from-fuchsia-500 via-white to-cyan-500 animate-pulse shadow-[0_0_30px_white]', desc: 'ARQUITETO DA REALIDADE' }, 
  { name: 'DEUS EX MACHINA', minLevel: 100000, maxLevel: 999999, color: 'bg-white text-black font-black tracking-widest shadow-[0_0_50px_white]', desc: 'CONTROLE TOTAL' }, 
];

const getEvolutionDetails = (level: number) => {
  const tier = EVOLUTION_TIERS.find(t => level >= t.minLevel && level <= t.maxLevel) || EVOLUTION_TIERS[EVOLUTION_TIERS.length - 1];
  const tierRange = tier.maxLevel - tier.minLevel + 1;
  const levelInTier = level - tier.minLevel;
  const progressPercent = Math.min(100, Math.max(5, (levelInTier / tierRange) * 100));

  return { tier, progressPercent };
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState('');
  const [binanceKey, setBinanceKey] = useState('');
  const [binanceSecret, setBinanceSecret] = useState('');
  const [marketType, setMarketTypeState] = useState<MarketType>('spot');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [marketData, setMarketData] = useState<MarketDataPoint[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analysis' | 'settings' | 'creator' | 'risk' | 'decision' | 'bioquantum' | 'architect' | 'crm' | 'trader' | 'network' | 'quantum_analysis' | 'chaos' | 'arbitrage' | 'optimization' | 'simulation' | 'prediction' | 'omega' | 'autonomous' | 'risk_manager' | 'strategy_optimizer' | 'auto_system' | 'validation' | 'autonomous_decision' | 'trading_controller' | 'simulation_trader' | 'exchange_cmd' | 'dependency_dashboard' | 'environment_dashboard' | 'neural_precision' | 'neural_override' | 'neural_operations' | 'neural_indicator_integration' | 'neural_connection_matrix' | 'broker_integration' | 'auth_manager' | 'system_diagnostics' | 'automation_dashboard' | 'profitability' | 'neuroplasticity' | 'banking'>('dashboard');
  const [aiAnalysis, setAiAnalysis] = useState<AnalysisResult | null>(null);
  
  // State variables for application logic
  const [autonomousMode, setAutonomousMode] = useState(true);
  const [isTraining, setIsTraining] = useState(false);
  const [evolutionLevel, setEvolutionLevel] = useState(1);
  const [aiBroadcast, setAiBroadcast] = useState<string | null>("Sistema Online. Módulos Ativos. Aguardando confiança > 85% para execução.");
  
  // Data States
  const [trades, setTrades] = useState<Trade[]>([]);
  const [swarmAgents, setSwarmAgents] = useState<SwarmAgent[]>([]);
  const [activeRegime, setActiveRegime] = useState<MarketRegime>(MarketRegime.SIDEWAYS_QUIET);
  const [currentVolatility, setCurrentVolatility] = useState(0);
  const [riskSettings, setRiskSettings] = useState<RiskSettings>({
      maxDrawdownLimit: 5,
      maxPositionSize: 10,
      stopLossDefault: 2,
      dailyLossLimit: 100,
      riskPerTrade: 1
  });
  const [wallet, setWallet] = useState<WalletBalance>({
      totalUsdt: 50000,
      freeUsdt: 50000,
      totalBtc: 0,
      freeBtc: 0,
      estimatedTotalValue: 50000
  });
  const [layers, setLayers] = useState<LayerActivity[]>([
      { id: 'MultiScaleCNN', status: 'IDLE', load: 10, description: 'Visual Cortex' },
      { id: 'HyperCognitionEngine', status: 'PROCESSING', load: 45, description: 'Main Processor' },
      { id: 'RiskManager', status: 'IDLE', load: 5, description: 'Risk Control' },
      { id: 'QuantumEnhancedArchitecture', status: 'OPTIMIZING', load: 30, description: 'Quantum Bridge' }
  ]);
  const [opportunities, setOpportunities] = useState<TradingSignal[]>([]);

  // Handlers
  const handleAuthenticated = (user: string) => {
      setCurrentUser(user);
      setIsAuthenticated(true);
  };

  const toggleMarketType = () => {
      setMarketTypeState(prev => prev === 'spot' ? 'future' : 'spot');
  };

  const startDeepLearning = async () => {
      setIsTraining(true);
      setAiBroadcast("Iniciando treinamento profundo...");
      await new Promise(resolve => setTimeout(resolve, 3000));
      setEvolutionLevel(prev => prev + 1);
      setIsTraining(false);
      setAiBroadcast("Treinamento concluído. Novos padrões assimilados.");
  };

  const handleFeedback = (tradeId: string, positive: boolean) => {
      setTrades(prev => prev.map(t => t.id === tradeId ? { ...t, feedback: positive ? 'POSITIVE' : 'NEGATIVE' } : t));
  };

  const executeMarketAnalysis = async () => {
      setAiBroadcast("Analisando mercado...");
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAiAnalysis({
          signal: 'HOLD',
          confidence: 0.85,
          reasoning: "Análise manual solicitada. Padrões estáveis.",
          pattern: "Manual Scan",
          suggestedEntry: 0,
          suggestedStopLoss: 0,
          suggestedTakeProfit: 0,
          internalMonologue: "Scanning markets for manual review...",
          orderType: 'MARKET',
          deepReasoning: {
              technical: { pattern: 'SCAN', signal: 'HOLD' },
              fundamental: { macroSentiment: 'NEUTRAL', impactScore: 0 },
              sentiment: { score: 0, dominantEmotion: 'NEUTRAL', newsImpact: 'NONE' },
              neuralAnalysis: { modelArchitecture: 'CNN', inputFeatures: [], layerActivations: [], predictionHorizon: '1H', lossFunctionValue: 0, trainingEpochs: 0 },
              risk: { suggestedLeverage: 1, positionSize: '0', stopLossDynamic: 0, takeProfitDynamic: 0 },
              virtualUserAction: 'MONITORING',
              metacognition: { selfReflection: 'Manual analysis triggered.', biasDetection: 'N/A', alternativeScenario: 'N/A', confidenceInterval: { min:0, max:0 } }
          }
      });
      setAiBroadcast("Análise concluída.");
  };

  const handlePanic = () => {
      setAiBroadcast("PROTOCOLO DE PÂNICO ATIVADO. Cancelando ordens...");
      setAutonomousMode(false);
  };

  useEffect(() => {
      if (!isAuthenticated) return;
      
      const interval = setInterval(() => {
          setMarketData(prev => {
              const lastPrice = prev.length > 0 ? prev[prev.length - 1].price : 50000;
              const newPrice = lastPrice * (1 + (Math.random() - 0.5) * 0.002);
              const newData: MarketDataPoint = {
                  time: new Date().toLocaleTimeString(),
                  price: newPrice,
                  open: lastPrice,
                  high: Math.max(lastPrice, newPrice) * 1.001,
                  low: Math.min(lastPrice, newPrice) * 0.999,
                  volume: Math.random() * 1000,
                  ma7: newPrice,
                  ma25: newPrice,
                  rsi: 50 + Math.random() * 20 - 10,
                  bbUpper: newPrice * 1.01,
                  bbLower: newPrice * 0.99,
                  macd: 0, macdSignal: 0, macdHist: 0, atr: 50, stochK: 50, stochD: 50,
                  vwap: newPrice, cci: 0, obv: 0, ichiTenkan: newPrice, ichiKijun: newPrice, ichiSenkouA: newPrice, ichiSenkouB: newPrice
              };
              return [...prev.slice(-100), newData];
          });
          
          if (Math.random() > 0.9) {
              setCurrentVolatility(Math.random() * 5);
              setActiveRegime(Math.random() > 0.5 ? MarketRegime.BULL_TREND : MarketRegime.SIDEWAYS_QUIET);
          }
      }, 1000);
      
      return () => clearInterval(interval);
  }, [isAuthenticated]);

  const evoDetails = getEvolutionDetails(evolutionLevel);

  if (!isAuthenticated) return <AuthScreen onAuthenticated={handleAuthenticated} />;

  return (
    <div className="flex h-screen bg-matrix-black text-gray-300 overflow-hidden font-sans">
      {isMobile && isSidebarOpen && (
        <div className="fixed inset-0 bg-black/80 z-40 backdrop-blur-sm" onClick={() => setIsSidebarOpen(false)}></div>
      )}

      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-matrix-panel border-r border-matrix-border transition-transform duration-300 ease-in-out flex flex-col ${isMobile ? (isSidebarOpen ? 'translate-x-0' : '-translate-x-full') : 'relative translate-x-0'}`}>
        <div className="p-4 flex items-center justify-between border-b border-matrix-border">
          <div className="flex items-center gap-2"><Brain className="text-quantum-500 animate-pulse" size={24} /><span className="font-bold text-white tracking-wider">LEXTRADER</span></div>
          {isMobile && <button onClick={() => setIsSidebarOpen(false)} className="p-1 hover:bg-white/10 rounded"><X size={20} /></button>}
        </div>
        <nav className="flex-1 py-6 space-y-2 px-2 overflow-y-auto">
          {[
            { id: 'dashboard', icon: Activity, label: 'Terminal Quântico' },
            { id: 'banking', icon: Landmark, label: 'Financeiro & Banking' }, // NEW ITEM
            { id: 'neuroplasticity', icon: BrainCircuit, label: 'Neuroplasticidade Dinâmica' }, 
            { id: 'profitability', icon: TrendingUp, label: 'Estratégias de Lucratividade' }, 
            { id: 'automation_dashboard', icon: Globe, label: 'Automação Global' },
            { id: 'system_diagnostics', icon: HardDrive, label: 'Diagnóstico de Sistema' },
            { id: 'auth_manager', icon: Key, label: 'Acesso & Chaves' }, 
            { id: 'broker_integration', icon: Building2, label: 'Corretoras & HomeBroker' },
            { id: 'neural_indicator_integration', icon: Gauge, label: 'Integração de Indicadores' }, 
            { id: 'environment_dashboard', icon: Laptop, label: 'Diagnóstico de Ambiente' },
            { id: 'neural_connection_matrix', icon: Share2, label: 'Matriz de Conexão Neural' }, 
            { id: 'neural_operations', icon: BrainCircuit, label: 'Análise de Operações' }, 
            { id: 'neural_precision', icon: Crosshair, label: 'Precisão Neural' },
            { id: 'neural_override', icon: Hand, label: 'Override Neural' },
            { id: 'dependency_dashboard', icon: Package, label: 'Dependências do Sistema' }, 
            { id: 'exchange_cmd', icon: Terminal, label: 'Exchange Command' },
            { id: 'omega', icon: RadioTower, label: 'Omega Trading' }, 
            { id: 'simulation_trader', icon: PlayCircle, label: 'Simulador AutoTrader' }, 
            { id: 'trading_controller', icon: Command, label: 'Controlador Autônomo' }, 
            { id: 'autonomous_decision', icon: Gavel, label: 'Motor de Decisão' }, 
            { id: 'validation', icon: Stethoscope, label: 'Validador Autônomo' },
            { id: 'auto_system', icon: Cog, label: 'Sistema Autônomo' }, 
            { id: 'strategy_optimizer', icon: GitMerge, label: 'Otimizador de Estratégia' },
            { id: 'risk_manager', icon: Shield, label: 'Risk Manager Autônomo' }, 
            { id: 'autonomous', icon: Bot, label: 'Gerenciador Autônomo' },
            { id: 'simulation', icon: Workflow, label: 'Simulador Quântico' },
            { id: 'prediction', icon: Server, label: 'Previsão Avançada' }, 
            { id: 'quantum_analysis', icon: Waves, label: 'Análise Quântica' },
            { id: 'chaos', icon: Flame, label: 'Análise do Caos' }, 
            { id: 'optimization', icon: FunctionSquare, label: 'Otimização QAOA' }, 
            { id: 'arbitrage', icon: Scale, label: 'Arbitragem Quântica' }, 
            { id: 'trader', icon: LineChart, label: 'Trader Autônomo' },
            { id: 'network', icon: Network, label: 'Quantum Network' },
            { id: 'bioquantum', icon: Database, label: 'BioQuantum System' },
            { id: 'decision', icon: GitBranch, label: 'Motor de Decisão (Old)' },
            { id: 'analysis', icon: BarChart3, label: 'Análise Profunda' },
            { id: 'creator', icon: Dna, label: 'Criador Neural' },
            { id: 'risk', icon: ShieldAlert, label: 'Gestão de Risco' },
            { id: 'architect', icon: Code2, label: 'Arquiteto de Código' }, 
            { id: 'crm', icon: Briefcase, label: 'CRM Quântico' },
            { id: 'settings', icon: Settings, label: 'Centro de Comando' },
          ].map((item) => (
            <button key={item.id} onClick={() => { setActiveTab(item.id as any); if(isMobile) setIsSidebarOpen(false); }} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${activeTab === item.id ? 'bg-quantum-900/40 text-quantum-400 border border-quantum-500/50 shadow-[0_0_15px_rgba(14,165,233,0.1)]' : 'hover:bg-white/5 text-gray-400'}`}>
              <item.icon size={20} /><span>{item.label}</span>
            </button>
          ))}
        </nav>
        {/* ... */}
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 bg-matrix-panel/50 backdrop-blur-md border-b border-matrix-border flex items-center justify-between px-4 md:px-6 z-10">
          <div className="flex items-center gap-4">
             {isMobile && <button onClick={() => setIsSidebarOpen(true)} className="p-1 hover:bg-white/10 rounded md:hidden"><Menu size={20} /></button>}
             <div className="flex items-center gap-2 md:gap-4 overflow-x-auto scrollbar-hide">
                <div className={`bg-quantum-900/30 border ${marketType === 'spot' ? 'border-quantum-800' : 'border-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.3)]'} rounded px-3 py-1 flex items-center gap-2 transition-all whitespace-nowrap`}><span className={`text-[10px] md:text-xs font-mono font-bold ${marketType === 'spot' ? 'text-quantum-400' : 'text-purple-400'}`}>BINANCE {marketType === 'spot' ? 'SPOT' : 'FUTURES'}</span></div>
                <button onClick={toggleMarketType} className="text-[10px] bg-gray-800 hover:bg-gray-700 px-2 py-1 rounded border border-gray-600 transition-colors whitespace-nowrap">{isMobile ? 'MUDAR' : 'ALTERNAR'}</button>
             </div>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <button onClick={() => setAutonomousMode(!autonomousMode)} className={`flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-lg text-xs md:text-sm font-semibold transition-all whitespace-nowrap ${autonomousMode ? 'bg-green-500/10 text-green-400 border border-green-500/50 shadow-[0_0_10px_rgba(34,197,94,0.2)]' : 'bg-gray-800 text-gray-400 border border-gray-700'}`}>{autonomousMode ? <Zap size={14} /> : <Lock size={14} />}{autonomousMode ? (isMobile ? 'AUTO' : 'SISTEMA AUTÔNOMO') : (isMobile ? 'MANUAL' : 'MANUAL')}</button>
          </div>
        </header>

        {activeTab === 'creator' ? <AutonomousCreator agents={swarmAgents} regime={activeRegime} /> : 
         activeTab === 'risk' ? <RiskDashboard trades={trades} marketData={marketData} currentVolatility={currentVolatility} settings={riskSettings} onUpdateSettings={setRiskSettings} /> : 
         activeTab === 'decision' ? <div className="p-6 h-full overflow-hidden"><DecisionEngine /></div> : 
         activeTab === 'bioquantum' ? <div className="h-full overflow-hidden"><BioQuantumTerminal marketData={marketData} /></div> :
         activeTab === 'architect' ? <div className="h-full overflow-hidden"><CodeArchitect /></div> :
         activeTab === 'crm' ? <div className="h-full overflow-hidden"><QuantumCRM /></div> :
         activeTab === 'trader' ? <div className="h-full overflow-hidden"><QuantumTradersDashboard /></div> :
         activeTab === 'network' ? <div className="h-full overflow-hidden"><QuantumNetworkDashboard /></div> :
         activeTab === 'quantum_analysis' ? <div className="h-full overflow-hidden"><QuantumAnalysisVisualizer marketData={marketData} symbol="BTC/USDT" /></div> :
         activeTab === 'chaos' ? <div className="h-full overflow-hidden"><QuantumAnalysis /></div> :
         activeTab === 'arbitrage' ? <div className="h-full overflow-hidden"><QuantumArbitrageDashboard /></div> :
         activeTab === 'optimization' ? <div className="h-full overflow-hidden"><QuantumOptimizationDashboard /></div> :
         activeTab === 'simulation' ? <div className="h-full overflow-hidden"><QuantumSimulationTerminal /></div> :
         activeTab === 'prediction' ? <div className="h-full overflow-hidden"><AdvancedPredictionDashboard /></div> :
         activeTab === 'omega' ? <div className="h-full overflow-hidden"><OmegaTerminal /></div> :
         activeTab === 'autonomous' ? <div className="h-full overflow-hidden"><AutonomousDashboard /></div> :
         activeTab === 'risk_manager' ? <div className="h-full overflow-hidden"><RiskManagerDashboard /></div> : 
         activeTab === 'strategy_optimizer' ? <div className="h-full overflow-hidden"><StrategyOptimizerDashboard /></div> :
         activeTab === 'auto_system' ? <div className="h-full overflow-hidden"><AutonomousSystemDashboard /></div> :
         activeTab === 'validation' ? <div className="h-full overflow-hidden"><AutonomousValidationDashboard /></div> :
         activeTab === 'autonomous_decision' ? <div className="h-full overflow-hidden"><AutonomousDecisionEngine /></div> :
         activeTab === 'trading_controller' ? <div className="h-full overflow-hidden"><AutonomousTradingController /></div> : 
         activeTab === 'simulation_trader' ? <div className="h-full overflow-hidden"><AutoTraderSimulation /></div> : 
         activeTab === 'exchange_cmd' ? <div className="h-full overflow-hidden"><ExchangeCommandTerminal /></div> : 
         activeTab === 'dependency_dashboard' ? <div className="h-full overflow-hidden"><DependencyDashboard /></div> : 
         activeTab === 'environment_dashboard' ? <div className="h-full overflow-hidden"><EnvironmentDashboard /></div> : 
         activeTab === 'neural_precision' ? <div className="h-full overflow-hidden"><NeuralPrecisionEnhancer /></div> : 
         activeTab === 'neural_override' ? <div className="h-full overflow-hidden"><NeuralOverrideController /></div> : 
         activeTab === 'neural_operations' ? <div className="h-full overflow-hidden"><NeuralOperationsAnalyzer /></div> : 
         activeTab === 'neural_indicator_integration' ? <div className="h-full overflow-hidden"><NeuralIndicatorIntegration /></div> : 
         activeTab === 'neural_connection_matrix' ? <div className="h-full overflow-hidden"><NeuralConnectionMatrix evolutionLevel={evolutionLevel} /></div> :
         activeTab === 'broker_integration' ? <div className="h-full overflow-hidden"><BrokerIntegration /></div> :
         activeTab === 'auth_manager' ? <div className="h-full overflow-hidden"><PlatformAuthManager /></div> :
         activeTab === 'system_diagnostics' ? <div className="h-full overflow-hidden"><SystemDiagnostics /></div> : 
         activeTab === 'automation_dashboard' ? <div className="h-full overflow-hidden"><AutomationDashboard /></div> : 
         activeTab === 'profitability' ? <div className="h-full overflow-hidden"><ProfitabilityStrategy /></div> :
         activeTab === 'neuroplasticity' ? <div className="h-full overflow-hidden"><DynamicNeuroplasticitySystem /></div> :
         activeTab === 'banking' ? <div className="h-full overflow-hidden"><BankingInterface /></div> :
         activeTab === 'settings' ? <div className="flex-1 overflow-y-auto p-6 space-y-6"><h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><Settings className="text-quantum-400" /> CENTRO DE COMANDO</h2></div> :
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scrollbar-thin">
            {/* ... */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-matrix-panel border border-matrix-border p-4 rounded-lg relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity"><Wallet size={40} /></div>
                <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Patrimônio Total</div>
                <div className="text-2xl font-bold text-white font-mono">${wallet.estimatedTotalValue.toLocaleString()}</div>
              </div>
              
              <div className="bg-matrix-panel border border-matrix-border p-4 rounded-lg relative overflow-hidden flex flex-col justify-between">
                <div className="absolute top-0 right-0 p-2 opacity-10"><RefreshCw size={40} /></div>
                <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Aprendizado Profundo</div>
                <button onClick={startDeepLearning} disabled={isTraining} className="mt-2 w-full py-1 bg-quantum-900/30 hover:bg-quantum-900/50 text-quantum-400 text-xs rounded border border-quantum-900/50 transition-colors">{isTraining ? 'EVOLUINDO...' : 'TREINAR REDE NEURAL'}</button>
              </div>

              <div className="bg-matrix-panel border border-matrix-border p-4 rounded-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-10"><Cpu size={40} /></div>
                <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Confiança Neural</div>
                <div className={`text-2xl font-bold font-mono ${evoDetails.tier.color.includes('gradient') ? 'text-transparent bg-clip-text bg-gradient-to-r from-white to-cyan-400' : evoDetails.tier.color.replace('bg-', 'text-')}`}>{aiAnalysis ? Math.round(aiAnalysis.confidence * 100) : 0}%</div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-matrix-panel border border-matrix-border rounded-lg p-1">
                  {marketData.length > 0 ? <TradingChart data={marketData} /> : <div className="h-[500px] flex items-center justify-center text-gray-500">Inicializando Feed...</div>}
                </div>
                <DeepDiagnostics layers={layers} reasoning={aiAnalysis?.deepReasoning || null} />
                <OperationsCenter marketType={marketType} symbol="BTC/USDT" currentPrice={marketData[marketData.length - 1]?.price || 0} />
              </div>

              <div className="space-y-6">
                <div className="h-[300px]"><OpportunityScanner signals={opportunities} /></div>
                <div className="bg-matrix-panel border border-matrix-border rounded-lg p-4 h-[300px] flex flex-col">
                    <h3 className="text-sm font-semibold text-gray-300 mb-4 flex items-center justify-between"><span>APRENDIZADO</span><RefreshCw size={14} className="text-gray-600" /></h3>
                    <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                      {trades.map((trade) => (
                        <div key={trade.id} className="p-3 bg-black/30 border border-gray-800 rounded hover:border-gray-700 transition-colors group">
                          <div className="flex justify-between items-center mb-1"><span className={`text-xs font-bold ${trade.type === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>{trade.type} {trade.asset}</span><span className="text-[10px] text-gray-500 font-mono">{trade.timestamp.toLocaleTimeString()}</span></div>
                          <div className="flex justify-between items-center text-xs text-gray-400"><span>Est: {trade.strategy}</span><span className={trade.profit >= 0 ? 'text-green-500' : 'text-red-500'}>{trade.profit > 0 ? '+' : ''}{trade.profit.toFixed(2)}</span></div>
                          {!trade.feedback && trade.status === 'FILLED' && (<div className="mt-2 flex gap-2 justify-end opacity-50 group-hover:opacity-100 transition-opacity"><button onClick={() => handleFeedback(trade.id, true)} className="p-1 hover:bg-green-900/30 rounded text-gray-500 hover:text-green-400"><ThumbsUp size={12} /></button><button onClick={() => handleFeedback(trade.id, false)} className="p-1 hover:bg-red-900/30 rounded text-gray-500 hover:text-red-400"><ThumbsDown size={12} /></button></div>)}
                        </div>
                      ))}
                    </div>
                </div>
              </div>
            </div>
          </div>
        }
        <footer className="h-8 bg-matrix-black border-t border-matrix-border flex items-center justify-between px-4 text-[10px] text-gray-500">
          <div className="flex items-center gap-4"><span>Servidor: aws-us-east-1a</span><span>Latência: 23ms</span><span className="text-quantum-400 font-mono font-bold">Aprendizado Contínuo: ATIVO</span></div>
          <div>LEXTRADER-IAG v5.0-EVOLUTION</div>
        </footer>
      </main>
      <Avatar 
        marketContext={JSON.stringify(marketData.slice(-5))} 
        broadcast={aiBroadcast} 
        onTriggerAnalysis={executeMarketAnalysis}
        onTriggerPanic={handlePanic}
      />
    </div>
  );
};

export default App;
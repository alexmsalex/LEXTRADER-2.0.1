// @ts-nocheck
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { Server } from 'socket.io';
import { createServer } from 'http';
import { initializeDatabase } from './database';
import { initializeStorageSystem } from './storage';
import { setupWebSocket } from './websocket';
import { setupModules } from './modules';
import { setupRoutes } from './api';

// Declare Node.js globals for frontend context
declare var process: any;
declare var require: any;
declare var module: any;

// Configurações
dotenv.config();

export class LexTraderServer {
  private app: express.Application;
  private server: any;
  private io: any;
  private port: number;
  
  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '8080');
    this.server = createServer(this.app);
    this.io = new Server(this.server, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    this.initialize();
  }
  
  private async initialize() {
    // Criar estrutura de diretórios
    await this.createDirectoryStructure();
    
    // Inicializar componentes
    await initializeDatabase();
    await initializeStorageSystem();
    
    // Configurar middleware
    this.setupMiddleware();
    
    // Configurar rotas
    this.setupRoutes();
    
    // Configurar WebSocket
    setupWebSocket(this.io);
    
    // Carregar módulos do LEXTRADER
    await setupModules();
    
    // Configurar handlers de erro
    this.setupErrorHandling();
  }
  
  private async createDirectoryStructure() {
    const basePath = path.join(os.homedir(), '.lextrader-iag');
    const dirs = [
      basePath,
      path.join(basePath, 'storage'),
      path.join(basePath, 'storage', 'users'),
      path.join(basePath, 'storage', 'backups'),
      path.join(basePath, 'storage', 'temp'),
      path.join(basePath, 'database'),
      path.join(basePath, 'logs'),
      path.join(basePath, 'modules'),
      path.join(basePath, 'config'),
      path.join(basePath, 'cache')
    ];
    
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
    
    console.log('📁 Estrutura de diretórios criada:', basePath);
  }
  
  private setupMiddleware() {
    // Segurança
    this.app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"]
        }
      }
    }));
    
    this.app.use(cors({
      origin: process.env.CLIENT_URL || '*',
      credentials: true
    }));
    
    this.app.use(compression());
    this.app.use(express.json({ limit: '50mb' }));
    this.app.use(express.urlencoded({ extended: true }));
    
    // Rate limiting
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 1000,
      message: 'Muitas requisições deste IP'
    });
    this.app.use('/api/', limiter);
    
    // Logging
    this.app.use((req, res, next) => {
      console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
      next();
    });
  }
  
  private setupRoutes() {
    // API Routes
    this.app.use('/api', setupRoutes());
    
    // Servir arquivos estáticos
    this.app.use('/storage', express.static(
      path.join(os.homedir(), '.lextrader-iag', 'storage')
    ));
    
    // Rota de status
    this.app.get('/status', (req, res) => {
      res.json({
        status: 'online',
        version: '2.0.0',
        server: 'LEXTRADER-IAG Cloud Server',
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        system: {
          platform: os.platform(),
          arch: os.arch(),
          totalMemory: os.totalmem(),
          freeMemory: os.freemem(),
          cpus: os.cpus().length
        }
      });
    });
    
    // Rota principal
    this.app.get('/', (req, res) => {
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>LEXTRADER-IAG 2.0 Server</title>
          <style>
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              height: 100vh;
              display: flex;
              justify-content: center;
              align-items: center;
              margin: 0;
            }
            .container {
              background: white;
              padding: 40px;
              border-radius: 20px;
              box-shadow: 0 20px 60px rgba(0,0,0,0.3);
              text-align: center;
              max-width: 600px;
            }
            .logo {
              font-size: 48px;
              margin-bottom: 20px;
            }
            h1 {
              color: #333;
              margin-bottom: 10px;
            }
            .status {
              background: #10b981;
              color: white;
              padding: 10px 20px;
              border-radius: 50px;
              display: inline-block;
              margin: 20px 0;
            }
            .links {
              margin-top: 30px;
            }
            .link {
              display: inline-block;
              margin: 10px;
              padding: 12px 24px;
              background: #667eea;
              color: white;
              text-decoration: none;
              border-radius: 8px;
              transition: transform 0.3s;
            }
            .link:hover {
              transform: translateY(-2px);
              background: #5a6fd8;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="logo">⚡</div>
            <h1>LEXTRADER-IAG 2.0</h1>
            <p>Seu PC agora é um servidor cloud privado!</p>
            <div class="status">🚀 SERVIDOR ONLINE</div>
            <div class="links">
              <a href="/api/status" class="link">📊 Status API</a>
              <a href="/storage" class="link">📁 Storage</a>
              <a href="/ws" class="link">🔌 WebSocket</a>
            </div>
          </div>
        </body>
        </html>
      `);
    });
  }
  
  private setupErrorHandling() {
    // 404
    this.app.use((req, res, next) => {
      res.status(404).json({
        error: 'Rota não encontrada',
        path: req.path
      });
    });
    
    // Error handler
    this.app.use((err: any, req: any, res: any, next: any) => {
      console.error('Erro no servidor:', err);
      res.status(err.status || 500).json({
        error: 'Erro interno do servidor',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
      });
    });
  }
  
  public start() {
    this.server.listen(this.port, () => {
      const interfaces = os.networkInterfaces();
      console.log(`
      ╔═══════════════════════════════════════════════════════════╗
      ║                                                           ║
      ║      🚀 LEXTRADER-IAG 2.0 SERVER INICIADO                ║
      ║           Seu PC agora é um servidor cloud!              ║
      ║                                                           ║
      ╠═══════════════════════════════════════════════════════════╣
      ║                                                           ║
      ║   📍 URL Local:    http://localhost:${this.port}              ║
      ║                                                           ║`);
      
      Object.keys(interfaces).forEach(iface => {
        interfaces[iface]?.forEach(details => {
          if (details.family === 'IPv4' && !details.internal) {
            console.log(`      ║   🌐 URL Rede:    http://${details.address}:${this.port}  ║`);
          }
        });
      });
      
      console.log(`      ║                                                           ║
      ║   🔐 Admin:       admin / admin123                     ║
      ║   📁 Storage:     ${path.join(os.homedir(), '.lextrader-iag')} ║
      ║   🗄️  Database:    SQLite                              ║
      ║   ⚡ Módulos:     Trading, Análise, IA                ║
      ║                                                           ║
      ╚═══════════════════════════════════════════════════════════╝
      `);
    });
  }
  
  public stop() {
    this.server.close(() => {
      console.log('🛑 Servidor LEXTRADER-IAG encerrado');
    });
  }
}

// Inicializar servidor
if (require.main === module) {
  const server = new LexTraderServer();
  server.start();
  
  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n🔻 Recebido SIGINT. Encerrando servidor...');
    server.stop();
    process.exit(0);
  });
  
  process.on('SIGTERM', () => {
    console.log('\n🔻 Recebido SIGTERM. Encerrando servidor...');
    server.stop();
    process.exit(0);
  });
}

export default LexTraderServer;